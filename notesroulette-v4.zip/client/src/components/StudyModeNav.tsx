import { Brain, BookOpen, Layers3, MessageCircle, Target } from "lucide-react";
import { Link, useLocation } from "wouter";

export function StudyModeNav({ bookId }: { bookId: number }) {
  const [location] = useLocation();
  const items = [{ href: `/notes/${bookId}`, label: "Notes", icon: BookOpen }, { href: `/exam/${bookId}`, label: "Exam Mode", icon: Target }, { href: `/quiz/${bookId}`, label: "Quiz", icon: Brain }, { href: `/flashcards/${bookId}`, label: "Flashcards", icon: Layers3 }, { href: `/chat/${bookId}`, label: "Ask AI", icon: MessageCircle }];
  return <nav className="study-mode-nav" aria-label="Study modes">{items.map(item => <Link key={item.href} href={item.href} className={location === item.href ? "is-active" : ""}><item.icon className="h-4 w-4" /> {item.label}</Link>)}</nav>;
}
