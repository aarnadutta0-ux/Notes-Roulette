export function BrandMark({ compact = false }: { compact?: boolean }) {
  return <div className="brand-mark" aria-label="Notes Roulette"><span className="brand-orbit" aria-hidden="true"><span className="brand-dot dot-a" /><span className="brand-dot dot-b" /><span className="brand-dot dot-c" /><span className="brand-dot dot-d" /><span className="brand-dot dot-e" /><span className="brand-dot dot-f" /><span className="brand-n">N</span></span>{!compact && <span className="brand-wordmark">Notes <em>Roulette</em></span>}</div>;
}
