import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useRoute } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AppShell } from "./components/AppShell";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Upload from "./pages/Upload";
import Library from "./pages/Library";
import StudyHub from "./pages/StudyHub";
import Processing from "./pages/Processing";
import NotesPreview from "./pages/NotesPreview";
import ExamMode from "./pages/ExamMode";
import QuizMode from "./pages/QuizMode";
import Flashcards from "./pages/Flashcards";
import Chat from "./pages/Chat";
import Login from "./pages/Login";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";
function Protected({ children }: { children: React.ReactNode }) { return <AppShell>{children}</AppShell>; }
function ProcessingRoute() { const [, params] = useRoute("/processing/:jobId"); return <Protected><Processing jobId={Number(params?.jobId)} /></Protected>; }
function NotesRoute() { const [, params] = useRoute("/notes/:bookId"); return <Protected><NotesPreview bookId={Number(params?.bookId)} /></Protected>; }
function ExamRoute() { const [, params] = useRoute("/exam/:bookId"); return <Protected><ExamMode bookId={Number(params?.bookId)} /></Protected>; }
function QuizRoute() { const [, params] = useRoute("/quiz/:bookId"); return <Protected><QuizMode bookId={Number(params?.bookId)} /></Protected>; }
function FlashcardsRoute() { const [, params] = useRoute("/flashcards/:bookId"); return <Protected><Flashcards bookId={Number(params?.bookId)} /></Protected>; }
function ChatRoute() { const [, params] = useRoute("/chat/:bookId"); return <Protected><Chat bookId={Number(params?.bookId)} /></Protected>; }
function Router() { return <Switch><Route path="/" component={Home} /><Route path="/app"><Protected><Dashboard /></Protected></Route><Route path="/library"><Protected><Library /></Protected></Route><Route path="/study"><Protected><StudyHub /></Protected></Route><Route path="/upload"><Protected><Upload /></Protected></Route><Route path="/processing/:jobId" component={ProcessingRoute} /><Route path="/notes/:bookId" component={NotesRoute} /><Route path="/exam/:bookId" component={ExamRoute} /><Route path="/quiz/:bookId" component={QuizRoute} /><Route path="/flashcards/:bookId" component={FlashcardsRoute} /><Route path="/chat/:bookId" component={ChatRoute} /><Route path="/login" component={Login} /><Route path="/settings"><Protected><Settings /></Protected></Route><Route path="/404" component={NotFound} /><Route component={NotFound} /></Switch>; }
export default function App() { return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>; }
