import { ArrowLeft, Loader2, MessageCircle, SendHorizontal, Trash2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { Streamdown } from "streamdown";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { StudyModeNav } from "@/components/StudyModeNav";
import type { SourceRef } from "@shared/notes";

type Message = { id: string; role: "user" | "assistant"; content: string; sourceRefs?: SourceRef[]; mode?: "ai" | "extractive"; failed?: boolean };
const SUGGESTIONS = ["Explain this chapter in simple words", "What are the most important points to remember?", "Give me an example to understand this better", "What could be asked in an exam from this?"];

function storageKey(bookId: number, chapter: string) { return `notesroulette:chat:${bookId}:${chapter || "book"}`; }
function loadMessages(key: string): Message[] { try { const parsed = JSON.parse(localStorage.getItem(key) || "[]"); return Array.isArray(parsed) ? parsed.slice(-60) : []; } catch { return []; } }

export default function Chat({ bookId }: { bookId: number }) {
  const chapters = trpc.study.chapters.useQuery({ bookId });
  const [chapter, setChapter] = useState(() => new URLSearchParams(window.location.search).get("chapter") ?? "");
  const [messages, setMessages] = useState<Message[]>(() => loadMessages(storageKey(bookId, new URLSearchParams(window.location.search).get("chapter") ?? "")));
  const [draft, setDraft] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const ask = trpc.study.chat.ask.useMutation();
  const key = storageKey(bookId, chapter);

  useEffect(() => { setMessages(loadMessages(key)); }, [key]);
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(messages.slice(-60))); } catch { /* storage full or blocked: chat still works */ } }, [key, messages]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [messages, ask.isPending]);

  const send = async (text: string) => {
    const question = text.trim(); if (!question || ask.isPending) return;
    const history = messages.filter(message => !message.failed).map(({ role, content }) => ({ role, content }));
    setMessages(prev => [...prev, { id: crypto.randomUUID(), role: "user", content: question }]); setDraft("");
    try {
      const result = await ask.mutateAsync({ bookId, chapterTitle: chapter || undefined, question, history });
      setMessages(prev => [...prev, { id: crypto.randomUUID(), role: "assistant", content: result.answer, sourceRefs: result.sourceRefs, mode: result.mode }]);
    } catch (error) {
      setMessages(prev => [...prev, { id: crypto.randomUUID(), role: "assistant", failed: true, content: error instanceof Error ? error.message : "Something went wrong. Please try again." }]);
    }
  };

  return <div className="chat-page"><div className="notes-hero"><div><Link href={`/notes/${bookId}`} className="back-link"><ArrowLeft className="h-4 w-4" /> Notes</Link><span className="eyebrow eyebrow-lime"><MessageCircle className="h-3.5 w-3.5" /> Ask AI</span><h1>Stuck on something? Ask.</h1><p>Answers come from your uploaded material, with page references.</p></div></div><StudyModeNav bookId={bookId} />
    <div className="chat-card"><div className="chat-toolbar"><label><span>Ask about</span><select value={chapter} onChange={event => setChapter(event.target.value)}><option value="">Whole book / PDF</option>{(chapters.data ?? []).map(item => <option key={item.title} value={item.title}>{item.title} (pp. {item.startPage}–{item.endPage})</option>)}</select></label>{messages.length > 0 && <button className="chat-clear" onClick={() => { setMessages([]); ask.reset(); }}><Trash2 className="h-3.5 w-3.5" /> Clear chat</button>}</div>
      <div className="chat-thread" aria-live="polite">{messages.length === 0 && <div className="chat-empty"><MessageCircle className="h-7 w-7" /><p>Ask any doubt about {chapter ? "this chapter" : "your book"}. Try one of these:</p><div className="chat-suggestions">{SUGGESTIONS.map(text => <button key={text} onClick={() => send(text)}>{text}</button>)}</div></div>}
        {messages.map(message => <div key={message.id} className={`chat-msg is-${message.role}${message.failed ? " is-failed" : ""}`}><div className="chat-bubble">{message.role === "assistant" && !message.failed ? <Streamdown>{message.content}</Streamdown> : <p>{message.content}</p>}{message.sourceRefs && message.sourceRefs.length > 0 && <div className="chat-sources">{message.sourceRefs.map((ref, index) => <span key={index}>{ref.label || `pp. ${ref.startPage}–${ref.endPage}`}</span>)}</div>}</div></div>)}
        {ask.isPending && <div className="chat-msg is-assistant"><div className="chat-bubble chat-typing"><Loader2 className="h-4 w-4 animate-spin" /> Thinking…</div></div>}<div ref={endRef} /></div>
      <form className="chat-composer" onSubmit={event => { event.preventDefault(); void send(draft); }}><textarea value={draft} onChange={event => setDraft(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void send(draft); } }} placeholder="Type your doubt… (Enter to send, Shift+Enter for a new line)" rows={2} maxLength={2000} aria-label="Your question" /><Button type="submit" className="dark-button" disabled={ask.isPending || !draft.trim()}><SendHorizontal className="mr-2 h-4 w-4" /> Send</Button></form></div></div>;
}
