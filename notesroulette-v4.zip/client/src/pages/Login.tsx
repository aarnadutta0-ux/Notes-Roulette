import { Loader2, Sparkles } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { BrandMark } from "@/components/BrandMark";

export default function Login() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [name, setName] = useState(""); const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const onSuccess = async (result: { user: unknown }) => { utils.auth.me.setData(undefined, result.user as never); await utils.auth.me.invalidate(); setLocation("/app"); };
  const login = trpc.auth.login.useMutation({ onSuccess }); const signup = trpc.auth.signup.useMutation({ onSuccess });
  const active = mode === "login" ? login : signup; const pending = active.isPending;
  const submit = () => { if (pending) return; if (mode === "login") login.mutate({ email, password }); else signup.mutate({ email, password, name: name.trim() || undefined }); };
  const switchMode = (next: "login" | "signup") => { setMode(next); login.reset(); signup.reset(); };
  return <div className="auth-page"><Link href="/"><BrandMark /></Link>
    <form className="auth-card" onSubmit={event => { event.preventDefault(); submit(); }}>
      <span className="eyebrow eyebrow-lime"><Sparkles className="h-3.5 w-3.5" /> Private study studio</span>
      <h1>{mode === "login" ? "Welcome back." : "Create your account."}</h1>
      <p>{mode === "login" ? "Sign in to open your library and notes." : "Your books and notes stay private to your account."}</p>
      {mode === "signup" && <label className="auth-field"><span>Name (optional)</span><input value={name} onChange={event => setName(event.target.value)} autoComplete="name" maxLength={80} /></label>}
      <label className="auth-field"><span>Email</span><input type="email" value={email} onChange={event => setEmail(event.target.value)} autoComplete="email" required /></label>
      <label className="auth-field"><span>Password</span><input type="password" value={password} onChange={event => setPassword(event.target.value)} autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={mode === "signup" ? 8 : undefined} required /><small>{mode === "signup" ? "At least 8 characters." : ""}</small></label>
      {active.error && <div className="error-banner" role="alert"><span>{active.error.message}</span></div>}
      <Button type="submit" className="dark-button auth-submit" disabled={pending || !email || !password}>{pending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Please wait…</> : mode === "login" ? "Sign in" : "Create account"}</Button>
      <p className="auth-switch">{mode === "login" ? "New here? " : "Already have an account? "}<button type="button" onClick={() => switchMode(mode === "login" ? "signup" : "login")}>{mode === "login" ? "Create an account" : "Sign in"}</button></p>
    </form></div>;
}
