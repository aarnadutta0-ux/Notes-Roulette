CREATE TABLE `examSets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`ownerId` int NOT NULL,
	`scopeType` enum('book','chapter') NOT NULL,
	`chapterTitle` varchar(255),
	`subject` varchar(120) NOT NULL,
	`materialJson` text NOT NULL,
	`generationMode` enum('ai','extractive') NOT NULL DEFAULT 'ai',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `examSets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `flashcardSets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`ownerId` int NOT NULL,
	`scopeType` enum('book','chapter') NOT NULL,
	`chapterTitle` varchar(255),
	`subject` varchar(120) NOT NULL,
	`cardsJson` text NOT NULL,
	`progressJson` text NOT NULL,
	`generationMode` enum('ai','extractive') NOT NULL DEFAULT 'ai',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `flashcardSets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quizAttempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`quizSetId` int NOT NULL,
	`ownerId` int NOT NULL,
	`answersJson` text NOT NULL,
	`score` int NOT NULL,
	`total` int NOT NULL,
	`percentage` int NOT NULL,
	`weakTopicsJson` text NOT NULL,
	`completedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quizAttempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quizSets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`ownerId` int NOT NULL,
	`scopeType` enum('book','chapter') NOT NULL,
	`chapterTitle` varchar(255),
	`questionCount` int NOT NULL,
	`difficulty` enum('easy','medium','hard','mixed') NOT NULL,
	`questionType` enum('multiple-choice','true-false','mixed') NOT NULL,
	`materialJson` text NOT NULL,
	`generationMode` enum('ai','extractive') NOT NULL DEFAULT 'ai',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quizSets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `exam_sets_owner_book_idx` ON `examSets` (`ownerId`,`bookId`);--> statement-breakpoint
CREATE INDEX `exam_sets_scope_idx` ON `examSets` (`bookId`,`scopeType`,`chapterTitle`);--> statement-breakpoint
CREATE INDEX `flashcard_sets_owner_book_idx` ON `flashcardSets` (`ownerId`,`bookId`);--> statement-breakpoint
CREATE INDEX `flashcard_sets_scope_idx` ON `flashcardSets` (`bookId`,`scopeType`,`chapterTitle`);--> statement-breakpoint
CREATE INDEX `quiz_attempts_owner_quiz_idx` ON `quizAttempts` (`ownerId`,`quizSetId`);--> statement-breakpoint
CREATE INDEX `quiz_sets_owner_book_idx` ON `quizSets` (`ownerId`,`bookId`);--> statement-breakpoint
CREATE INDEX `quiz_sets_created_idx` ON `quizSets` (`bookId`,`createdAt`);