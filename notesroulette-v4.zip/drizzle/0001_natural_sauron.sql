CREATE TABLE `bookPreferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`ownerId` int NOT NULL,
	`detailLevel` enum('concise','balanced','detailed') NOT NULL DEFAULT 'balanced',
	`visualIntensity` enum('minimal','balanced','visual-heavy') NOT NULL DEFAULT 'balanced',
	`diagramPreference` enum('automatic','more','fewer') NOT NULL DEFAULT 'automatic',
	`includeSources` int NOT NULL DEFAULT 1,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bookPreferences_id` PRIMARY KEY(`id`),
	CONSTRAINT `bookPreferences_bookId_unique` UNIQUE(`bookId`)
);
--> statement-breakpoint
CREATE TABLE `books` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`ownerOpenId` varchar(64) NOT NULL,
	`originalFilename` varchar(255) NOT NULL,
	`title` varchar(255) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`sourceKind` enum('pdf','docx','epub','image') NOT NULL,
	`fileSize` int NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`checksum` varchar(64) NOT NULL,
	`pageCount` int NOT NULL DEFAULT 0,
	`subject` varchar(120),
	`status` enum('uploaded','processing','complete','failed','deleted') NOT NULL DEFAULT 'uploaded',
	`notesStatus` enum('none','processing','ready','failed') NOT NULL DEFAULT 'none',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `books_id` PRIMARY KEY(`id`),
	CONSTRAINT `books_owner_checksum_idx` UNIQUE(`ownerId`,`checksum`)
);
--> statement-breakpoint
CREATE TABLE `documentChunks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`ownerId` int NOT NULL,
	`chunkKey` varchar(160) NOT NULL,
	`chapterTitle` varchar(255) NOT NULL,
	`startPage` int NOT NULL,
	`endPage` int NOT NULL,
	`chunkIndex` int NOT NULL,
	`text` text NOT NULL,
	`analysisJson` text,
	CONSTRAINT `documentChunks_id` PRIMARY KEY(`id`),
	CONSTRAINT `document_chunks_key_idx` UNIQUE(`bookId`,`chunkKey`)
);
--> statement-breakpoint
CREATE TABLE `documentPages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`ownerId` int NOT NULL,
	`pageNumber` int NOT NULL,
	`text` text NOT NULL,
	`rawText` text,
	`confidence` int NOT NULL DEFAULT 100,
	`ocrRequired` int NOT NULL DEFAULT 0,
	`sourceKind` varchar(20) NOT NULL,
	`imagesJson` text,
	CONSTRAINT `documentPages_id` PRIMARY KEY(`id`),
	CONSTRAINT `document_pages_book_page_idx` UNIQUE(`bookId`,`pageNumber`)
);
--> statement-breakpoint
CREATE TABLE `noteDocuments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`ownerId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`subject` varchar(120) NOT NULL,
	`overview` text NOT NULL,
	`generatedJson` text NOT NULL,
	`generationMode` enum('ai','extractive') NOT NULL DEFAULT 'ai',
	`qcStatus` enum('pending','passed','needs_review') NOT NULL DEFAULT 'pending',
	`pdfStorageKey` varchar(512),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `noteDocuments_id` PRIMARY KEY(`id`),
	CONSTRAINT `noteDocuments_bookId_unique` UNIQUE(`bookId`)
);
--> statement-breakpoint
CREATE TABLE `noteSections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`noteDocumentId` int NOT NULL,
	`ownerId` int NOT NULL,
	`chapterTitle` varchar(255) NOT NULL,
	`title` varchar(255) NOT NULL,
	`summary` text NOT NULL,
	`bulletsJson` text NOT NULL,
	`keyTermsJson` text NOT NULL,
	`sourceRefsJson` text NOT NULL,
	`orderIndex` int NOT NULL,
	CONSTRAINT `noteSections_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `noteVisuals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`noteDocumentId` int NOT NULL,
	`ownerId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`strategy` enum('generated','extracted','redrawn') NOT NULL,
	`kind` varchar(40) NOT NULL,
	`description` text NOT NULL,
	`svg` text,
	`sourceRefsJson` text NOT NULL,
	CONSTRAINT `noteVisuals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `processingJobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`ownerId` int NOT NULL,
	`status` enum('queued','processing','complete','failed') NOT NULL DEFAULT 'queued',
	`stage` enum('uploading','reading','cleaning','chapters','analysing','notes','diagrams','quality','pdf','complete','failed') NOT NULL DEFAULT 'uploading',
	`progress` int NOT NULL DEFAULT 0,
	`currentChapter` int NOT NULL DEFAULT 0,
	`totalChapters` int NOT NULL DEFAULT 0,
	`attempts` int NOT NULL DEFAULT 0,
	`errorCode` varchar(80),
	`errorMessage` text,
	`activeKey` varchar(120),
	`startedAt` timestamp,
	`heartbeatAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `processingJobs_id` PRIMARY KEY(`id`),
	CONSTRAINT `jobs_active_key_idx` UNIQUE(`activeKey`)
);
--> statement-breakpoint
CREATE INDEX `books_owner_status_idx` ON `books` (`ownerId`,`status`);--> statement-breakpoint
CREATE INDEX `notes_owner_book_idx` ON `noteDocuments` (`ownerId`,`bookId`);--> statement-breakpoint
CREATE INDEX `note_sections_note_idx` ON `noteSections` (`noteDocumentId`,`orderIndex`);--> statement-breakpoint
CREATE INDEX `jobs_owner_status_idx` ON `processingJobs` (`ownerId`,`status`);--> statement-breakpoint
CREATE INDEX `jobs_book_idx` ON `processingJobs` (`bookId`);