import { index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const books = mysqlTable("books", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  ownerOpenId: varchar("ownerOpenId", { length: 64 }).notNull(),
  originalFilename: varchar("originalFilename", { length: 255 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  sourceKind: mysqlEnum("sourceKind", ["pdf", "docx", "epub", "image", "youtube"]).notNull(),
  fileSize: int("fileSize").notNull(),
  storageKey: varchar("storageKey", { length: 512 }).notNull(),
  checksum: varchar("checksum", { length: 64 }).notNull(),
  pageCount: int("pageCount").default(0).notNull(),
  subject: varchar("subject", { length: 120 }),
  status: mysqlEnum("status", ["uploaded", "processing", "complete", "failed", "deleted"]).default("uploaded").notNull(),
  notesStatus: mysqlEnum("notesStatus", ["none", "processing", "ready", "failed"]).default("none").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  ownerStatusIndex: index("books_owner_status_idx").on(table.ownerId, table.status),
  ownerChecksumIndex: uniqueIndex("books_owner_checksum_idx").on(table.ownerId, table.checksum),
}));

export const processingJobs = mysqlTable("processingJobs", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull(),
  ownerId: int("ownerId").notNull(),
  status: mysqlEnum("status", ["queued", "processing", "complete", "failed"]).default("queued").notNull(),
  stage: mysqlEnum("stage", ["uploading", "reading", "cleaning", "chapters", "analysing", "notes", "diagrams", "quality", "pdf", "complete", "failed"]).default("uploading").notNull(),
  progress: int("progress").default(0).notNull(),
  currentChapter: int("currentChapter").default(0).notNull(),
  totalChapters: int("totalChapters").default(0).notNull(),
  attempts: int("attempts").default(0).notNull(),
  errorCode: varchar("errorCode", { length: 80 }),
  errorMessage: text("errorMessage"),
  activeKey: varchar("activeKey", { length: 120 }),
  startedAt: timestamp("startedAt"),
  heartbeatAt: timestamp("heartbeatAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  ownerStatusIndex: index("jobs_owner_status_idx").on(table.ownerId, table.status),
  bookIndex: index("jobs_book_idx").on(table.bookId),
  activeKeyIndex: uniqueIndex("jobs_active_key_idx").on(table.activeKey),
}));

export const bookPreferences = mysqlTable("bookPreferences", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull().unique(),
  ownerId: int("ownerId").notNull(),
  detailLevel: mysqlEnum("detailLevel", ["concise", "balanced", "detailed"]).default("balanced").notNull(),
  visualIntensity: mysqlEnum("visualIntensity", ["minimal", "balanced", "visual-heavy"]).default("balanced").notNull(),
  diagramPreference: mysqlEnum("diagramPreference", ["automatic", "more", "fewer"]).default("automatic").notNull(),
  includeSources: int("includeSources").default(1).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const documentPages = mysqlTable("documentPages", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull(),
  ownerId: int("ownerId").notNull(),
  pageNumber: int("pageNumber").notNull(),
  text: text("text").notNull(),
  rawText: text("rawText"),
  confidence: int("confidence").default(100).notNull(),
  ocrRequired: int("ocrRequired").default(0).notNull(),
  sourceKind: varchar("sourceKind", { length: 20 }).notNull(),
  imagesJson: text("imagesJson"),
}, table => ({
  bookPageIndex: uniqueIndex("document_pages_book_page_idx").on(table.bookId, table.pageNumber),
}));

export const documentChunks = mysqlTable("documentChunks", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull(),
  ownerId: int("ownerId").notNull(),
  chunkKey: varchar("chunkKey", { length: 160 }).notNull(),
  chapterTitle: varchar("chapterTitle", { length: 255 }).notNull(),
  startPage: int("startPage").notNull(),
  endPage: int("endPage").notNull(),
  chunkIndex: int("chunkIndex").notNull(),
  text: text("text").notNull(),
  analysisJson: text("analysisJson"),
}, table => ({
  chunkKeyIndex: uniqueIndex("document_chunks_key_idx").on(table.bookId, table.chunkKey),
}));

export const noteDocuments = mysqlTable("noteDocuments", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull().unique(),
  ownerId: int("ownerId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  subject: varchar("subject", { length: 120 }).notNull(),
  overview: text("overview").notNull(),
  generatedJson: text("generatedJson").notNull(),
  generationMode: mysqlEnum("generationMode", ["ai", "extractive"]).default("ai").notNull(),
  qcStatus: mysqlEnum("qcStatus", ["pending", "passed", "needs_review"]).default("pending").notNull(),
  pdfStorageKey: varchar("pdfStorageKey", { length: 512 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({ ownerBookIndex: index("notes_owner_book_idx").on(table.ownerId, table.bookId) }));

export const noteSections = mysqlTable("noteSections", {
  id: int("id").autoincrement().primaryKey(),
  noteDocumentId: int("noteDocumentId").notNull(),
  ownerId: int("ownerId").notNull(),
  chapterTitle: varchar("chapterTitle", { length: 255 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  summary: text("summary").notNull(),
  bulletsJson: text("bulletsJson").notNull(),
  keyTermsJson: text("keyTermsJson").notNull(),
  sourceRefsJson: text("sourceRefsJson").notNull(),
  orderIndex: int("orderIndex").notNull(),
}, table => ({ noteIndex: index("note_sections_note_idx").on(table.noteDocumentId, table.orderIndex) }));

export const noteVisuals = mysqlTable("noteVisuals", {
  id: int("id").autoincrement().primaryKey(),
  noteDocumentId: int("noteDocumentId").notNull(),
  ownerId: int("ownerId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  strategy: mysqlEnum("strategy", ["generated", "extracted", "redrawn"]).notNull(),
  kind: varchar("kind", { length: 40 }).notNull(),
  description: text("description").notNull(),
  svg: text("svg"),
  sourceRefsJson: text("sourceRefsJson").notNull(),
});

export const examSets = mysqlTable("examSets", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull(),
  ownerId: int("ownerId").notNull(),
  scopeType: mysqlEnum("scopeType", ["book", "chapter"]).notNull(),
  chapterTitle: varchar("chapterTitle", { length: 255 }),
  subject: varchar("subject", { length: 120 }).notNull(),
  materialJson: text("materialJson").notNull(),
  generationMode: mysqlEnum("generationMode", ["ai", "extractive"]).default("ai").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({ ownerBookIndex: index("exam_sets_owner_book_idx").on(table.ownerId, table.bookId), scopeIndex: index("exam_sets_scope_idx").on(table.bookId, table.scopeType, table.chapterTitle) }));

export const quizSets = mysqlTable("quizSets", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull(),
  ownerId: int("ownerId").notNull(),
  scopeType: mysqlEnum("scopeType", ["book", "chapter"]).notNull(),
  chapterTitle: varchar("chapterTitle", { length: 255 }),
  questionCount: int("questionCount").notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard", "mixed"]).notNull(),
  questionType: mysqlEnum("questionType", ["multiple-choice", "true-false", "mixed"]).notNull(),
  materialJson: text("materialJson").notNull(),
  generationMode: mysqlEnum("generationMode", ["ai", "extractive"]).default("ai").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({ ownerBookIndex: index("quiz_sets_owner_book_idx").on(table.ownerId, table.bookId), createdIndex: index("quiz_sets_created_idx").on(table.bookId, table.createdAt) }));

export const quizAttempts = mysqlTable("quizAttempts", {
  id: int("id").autoincrement().primaryKey(),
  quizSetId: int("quizSetId").notNull(),
  ownerId: int("ownerId").notNull(),
  answersJson: text("answersJson").notNull(),
  score: int("score").notNull(),
  total: int("total").notNull(),
  percentage: int("percentage").notNull(),
  weakTopicsJson: text("weakTopicsJson").notNull(),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
}, table => ({ ownerQuizIndex: index("quiz_attempts_owner_quiz_idx").on(table.ownerId, table.quizSetId) }));

export const flashcardSets = mysqlTable("flashcardSets", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").notNull(),
  ownerId: int("ownerId").notNull(),
  scopeType: mysqlEnum("scopeType", ["book", "chapter"]).notNull(),
  chapterTitle: varchar("chapterTitle", { length: 255 }),
  subject: varchar("subject", { length: 120 }).notNull(),
  cardsJson: text("cardsJson").notNull(),
  progressJson: text("progressJson").notNull(),
  generationMode: mysqlEnum("generationMode", ["ai", "extractive"]).default("ai").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({ ownerBookIndex: index("flashcard_sets_owner_book_idx").on(table.ownerId, table.bookId), scopeIndex: index("flashcard_sets_scope_idx").on(table.bookId, table.scopeType, table.chapterTitle) }));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Book = typeof books.$inferSelect;
export type ProcessingJob = typeof processingJobs.$inferSelect;
export type BookPreference = typeof bookPreferences.$inferSelect;
export type DocumentPage = typeof documentPages.$inferSelect;
export type NoteDocument = typeof noteDocuments.$inferSelect;
export type ExamSet = typeof examSets.$inferSelect;
export type QuizSet = typeof quizSets.$inferSelect;
export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type FlashcardSet = typeof flashcardSets.$inferSelect;
