# Changes in this build

## 1. PDF now contains the diagrams

**Problem:** `server/pdf/render.ts` only printed text. `notes.visuals` was never read, so the PDF never
had any diagrams regardless of the "Visual intensity" / "Diagrams" settings. The visuals that were
generated were also placeholders ("key concept / source detail / revision cue") unrelated to the book.

**Fix:**

- `server/ai/pipeline.ts` – new `buildVisuals()` creates one diagram per chapter from that chapter's
  key terms (falling back to bullet openings). Chapters alternate between a **concept map** and a
  **flow** diagram. The number of diagrams honours the user's preferences:
  - Visual intensity: minimal = 1, balanced = 3, visual-heavy = up to 8
  - Diagrams: "more" adds 3, "fewer" removes them (visual-heavy keeps 1)
  - Both the AI path and the extractive fallback use the same builder.
- `shared/notes.ts` – `NoteVisual` gained optional `chapterTitle`, `centre`, `nodes` so the PDF and
  the browser preview render from the same structured data. Old stored notes still load.
- `server/pdf/render.ts` – draws each chapter's diagram right after its notes using PDFKit vector
  primitives (rounded rects, lines, arrows) – no new dependencies, no SVG rasterising. Also adds a
  diagram count to the cover/contents, a "Visual revision" page for unmatched visuals, and a
  "Quality check" page listing unresolved findings / extraction warnings.
- `server/jobs/worker.ts` – reports the `notes` and `diagrams` stages so the progress screen no longer
  skips them.
- `server/pdf/render.test.ts` – new test that exercises concept-map, flow and legacy visuals.

## 2. YouTube links work again

**Problem:** the `youtube-transcript` npm package scrapes the watch page and fetches caption URLs
that YouTube now serves empty (they require a proof-of-origin token) or blocks, so every link failed.

**Fix:** `server/youtube.ts` is now self-contained (no third-party package):

- Calls YouTube's InnerTube `player` endpoint with the **Android** client (its caption URLs still work
  without a token), then the **Web** client, then falls back to scraping the watch page.
- Fetches captions in `json3` format, with an XML fallback. Prefers manual English captions, then any
  manual track, then auto-generated.
- Reads the title from the player response (one less request).
- Accepts `youtu.be`, `youtube.com`, `m.`, `music.`, `youtube-nocookie.com`, watch/shorts/embed/live.
- Specific, user-facing errors via `YoutubeSourceError` codes: `INVALID_URL`, `NO_CAPTIONS`, `BLOCKED`
  (bot protection / rate limit), `UNAVAILABLE` (private, age-restricted…), `NETWORK`.
- `server/routers.ts` logs the failure code server-side so you can see why a link was rejected.

`youtube-transcript` is still listed in `package.json` so the lockfile and `pnpm install --frozen-lockfile`
in the Dockerfile keep working; you can drop it with `pnpm remove youtube-transcript` whenever you next
update dependencies.

> Note: YouTube aggressively rate-limits datacenter IPs. If your host hits a `BLOCKED` error, it is
> YouTube refusing the server, not a bug in the link parsing – retrying later or using a proxy helps.

## Verify before deploying

```bash
pnpm install
pnpm check      # type-check
pnpm test       # includes the new PDF diagram test
pnpm build && pnpm start
```

Then upload a short PDF, open the notes, and download the PDF – each chapter page should end with a
coloured diagram. Paste a YouTube link with captions to confirm the transcript flow.
## 3. Second pass (diagrams + YouTube)

- `server/ai/pipeline.ts` – when an AI provider is configured, each chapter now gets an AI-designed diagram
  (flow for processes/sequences, concept map for ideas) built only from that chapter's generated notes.
  If the AI call fails, that chapter falls back to the key-term diagram from section 1.
- `client/src/pages/NotesPreview.tsx` – diagrams now appear **inside each chapter** in the browser preview
  (they used to be tucked in the sidebar only). Unmatched/legacy diagrams stay in the sidebar.
- `server/youtube.ts` – added the `ANDROID_VR` InnerTube client to the fallback chain (order: ANDROID,
  ANDROID_VR, WEB, watch page).
- Not verified live: no network or `pnpm install` was available in the review sandbox, so `pnpm check`,
  `pnpm test` and real YouTube fetches still need to be run on your machine.

## 4. YouTube removed, "Ask AI" doubt chat added

**YouTube removed entirely:** `server/youtube.ts` and its two tests, the `books.youtube` API procedure, the YouTube
tab/card on the Upload page, the YouTube CSS, the `youtube-transcript` dependency (package.json + pnpm-lock.yaml) and the
YouTube branch of the extractor are gone. (Sections 2 and 3 above describe the old YouTube work and are kept only as history.)
The database enum still contains `"youtube"` on purpose so older databases/rows stay valid; the worker simply ignores that value.

**Ask AI (new):** a chat page at `/chat/:bookId` (tab "Ask AI" next to Notes / Exam / Quiz / Flashcards, and an
"Ask AI about this chapter" link under every chapter in the notes).
- Ask about the whole book/PDF or pick one chapter.
- `study.chat.ask` (server/routers.ts) is owner-checked, sends the most relevant parts of the uploaded material
  (`server/study/chat.ts`) plus the recent conversation to your configured AI provider, and returns a markdown answer
  with page references. Page references the model invents outside the supplied pages are dropped.
- If no AI provider is configured or the call fails, it falls back to showing the best-matching passages with page numbers.
- Chat history is kept in the browser (localStorage, per book and chapter) with a "Clear chat" button. It is not stored in the database.
- Tests: `server/study/chat.test.ts`.

## 5. Email + password login (works on Render or any host)

The Manus-only login can't run outside Manus, so the app now has its own sign-up / sign-in.
- New page `/login` (sign in / create account). Every "Sign in" button in the app now goes there.
- `auth.signup` and `auth.login` in `server/routers.ts`; passwords are stored as salted scrypt hashes
  (`server/auth/password.ts`, no new dependencies). Sessions reuse the existing signed cookie.
- Failed-login and sign-up rate limiting (in memory, per server).
- The credentials table (`user_credentials`) is created automatically on first use, so there is no extra migration to run.
- Required env var: `SESSION_SECRET` (any long random string; `MANUS_JWT_SECRET` also works).
- Limits: no password reset / email verification yet. Rate limits reset when the server restarts.
