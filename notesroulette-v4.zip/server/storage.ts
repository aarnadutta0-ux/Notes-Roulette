import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { ENV } from "./_core/env";

const LOCAL_ROOT = path.resolve(process.cwd(), ".runtime-storage");
function normalizeKey(relKey: string) { const normalized = relKey.replace(/^\/+/, ""); if (normalized.includes("..")) throw new Error("Invalid storage key"); return normalized; }
function appendHashSuffix(relKey: string) { const hash = crypto.randomUUID().replace(/-/g, "").slice(0, 8); const lastDot = relKey.lastIndexOf("."); return lastDot === -1 ? `${relKey}_${hash}` : `${relKey.slice(0, lastDot)}_${hash}${relKey.slice(lastDot)}`; }
function remoteConfigured() { return Boolean(ENV.forgeApiUrl && ENV.forgeApiKey); }
function localPath(key: string) { return path.join(LOCAL_ROOT, normalizeKey(key)); }

export async function storagePut(relKey: string, data: Buffer | Uint8Array | string, contentType = "application/octet-stream") {
  const key = appendHashSuffix(normalizeKey(relKey));
  if (!remoteConfigured()) { const target = localPath(key); await fs.mkdir(path.dirname(target), { recursive: true }); await fs.writeFile(target, typeof data === "string" ? Buffer.from(data) : Buffer.from(data)); return { key, url: `/manus-storage/${key}` }; }
  const forgeUrl = ENV.forgeApiUrl.replace(/\/+$/, "");
  const presignUrl = new URL("v1/storage/presign/put", `${forgeUrl}/`); presignUrl.searchParams.set("path", key);
  const presignResp = await fetch(presignUrl, { headers: { Authorization: `Bearer ${ENV.forgeApiKey}` } });
  if (!presignResp.ok) throw new Error(`Storage presign failed (${presignResp.status})`);
  const { url } = await presignResp.json() as { url?: string }; if (!url) throw new Error("Storage backend returned no upload URL");
  const uploadResp = await fetch(url, { method: "PUT", headers: { "Content-Type": contentType }, body: typeof data === "string" ? data : Buffer.from(data) }); if (!uploadResp.ok) throw new Error(`Storage upload failed (${uploadResp.status})`);
  return { key, url: `/manus-storage/${key}` };
}

export async function storageRead(relKey: string): Promise<Buffer> { const key = normalizeKey(relKey); if (!remoteConfigured()) return fs.readFile(localPath(key)); const url = await storageGetSignedUrl(key); const response = await fetch(url); if (!response.ok) throw new Error(`Storage read failed (${response.status})`); return Buffer.from(await response.arrayBuffer()); }
export async function storageDelete(relKey: string) { const key = normalizeKey(relKey); if (!remoteConfigured()) { await fs.rm(localPath(key), { force: true }); return; } }
export async function storageGetSignedUrl(relKey: string) { const key = normalizeKey(relKey); if (!remoteConfigured()) return `/manus-storage/${key}`; const forgeUrl = ENV.forgeApiUrl.replace(/\/+$/, ""); const getUrl = new URL("v1/storage/presign/get", `${forgeUrl}/`); getUrl.searchParams.set("path", key); const response = await fetch(getUrl, { headers: { Authorization: `Bearer ${ENV.forgeApiKey}` } }); if (!response.ok) throw new Error(`Storage signed URL failed (${response.status})`); const { url } = await response.json() as { url?: string }; if (!url) throw new Error("Storage backend returned no download URL"); return url; }
