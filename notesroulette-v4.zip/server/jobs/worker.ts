import crypto from "node:crypto";
import { getBookForOwner, getBookPreferences, getJobForOwner, insertDocumentPages, insertDocumentChunks, createNoteDocument, updateBookStatus, updateJob, updateJobProgress } from "../db";
import { storageDelete, storageRead } from "../storage";
import { extractDocument } from "../documents/extract";
import { chunkChapters } from "../documents/chunk";
import { generateNotes } from "../ai/pipeline";
import { renderNotesPdf } from "../pdf/render";
import type { BookPreferences } from "@shared/notes";

const running = new Set<number>();
function defaultPreferences(): BookPreferences { return { detailLevel: "balanced", visualIntensity: "balanced", diagramPreference: "automatic", includeSources: true }; }
function userMessage(error: unknown) { const message = error instanceof Error ? error.message : "Processing failed"; if (/OCR/i.test(message)) return { code: "OCR_UNAVAILABLE", message }; if (/AI provider/i.test(message)) return { code: "AI_UNAVAILABLE", message: "The AI service is not configured or temporarily unavailable. Retry when it is available." }; return { code: "PROCESSING_FAILED", message: "We could not finish reading this source. Check the file and try again." }; }

export async function processBookJob(jobId: number, ownerId: number) {
  if (running.has(jobId)) return;
  running.add(jobId);
  let generatedPdfKey: string | undefined;
  try {
    const job = await getJobForOwner(jobId, ownerId);
    if (!job || job.status === "complete") return;
    const book = await getBookForOwner(job.bookId, ownerId);
    if (!book) throw new Error("Book not found");
    const preferences = await getBookPreferences(book.id, ownerId) ?? defaultPreferences();
    await updateJob(jobId, ownerId, { status: "processing", stage: "reading", progress: 8, startedAt: new Date(), heartbeatAt: new Date(), attempts: (job.attempts ?? 0) + 1 });
    await updateBookStatus(book.id, ownerId, "processing", "processing");
    const source = await storageRead(book.storageKey);
    const extracted = await extractDocument({ data: source, filename: book.originalFilename, mime: book.mimeType, title: book.title, sourceKind: book.sourceKind === "youtube" ? undefined : book.sourceKind });
    await updateJobProgress(jobId, ownerId, { stage: "cleaning", progress: 18, heartbeatAt: new Date() });
    await insertDocumentPages(book.id, ownerId, extracted.pages);
    await updateBookStatus(book.id, ownerId, "processing", "processing", extracted.pageCount);
    const chunks = chunkChapters(extracted.chapters);
    await insertDocumentChunks(book.id, ownerId, chunks);
    await updateJobProgress(jobId, ownerId, { stage: "chapters", progress: 26, totalChapters: extracted.chapters.length, heartbeatAt: new Date() });
    const notes = await generateNotes(extracted, chunks, preferences, async (done, total) => { await updateJobProgress(jobId, ownerId, { stage: "analysing", progress: 30 + Math.round((done / Math.max(total, 1)) * 35), currentChapter: Math.min(done, extracted.chapters.length), totalChapters: extracted.chapters.length, heartbeatAt: new Date() }); });
    await updateJobProgress(jobId, ownerId, { stage: "notes", progress: 66, heartbeatAt: new Date() });
    await updateJobProgress(jobId, ownerId, { stage: "diagrams", progress: 70, totalChapters: extracted.chapters.length, currentChapter: extracted.chapters.length, heartbeatAt: new Date() });
    await updateJobProgress(jobId, ownerId, { stage: "quality", progress: 74, heartbeatAt: new Date() });
    const pdf = await renderNotesPdf(notes);
    await updateJobProgress(jobId, ownerId, { stage: "pdf", progress: 88, heartbeatAt: new Date() });
    const requestedPdfKey = `users/${ownerId}/books/${book.id}/notes-${crypto.randomUUID()}.pdf`;
    const storedPdf = await (await import("../storage")).storagePut(requestedPdfKey, pdf, "application/pdf");
    generatedPdfKey = storedPdf.key;
    await createNoteDocument({ bookId: book.id, ownerId, notes, pdfStorageKey: storedPdf.key });
    await updateBookStatus(book.id, ownerId, "complete", "ready", extracted.pageCount, notes.subject);
    await updateJob(jobId, ownerId, { status: "complete", stage: "complete", progress: 100, currentChapter: extracted.chapters.length, totalChapters: extracted.chapters.length, completedAt: new Date(), heartbeatAt: new Date(), errorCode: null, errorMessage: null, activeKey: null });
  } catch (error) {
    if (generatedPdfKey) { try { await storageDelete(generatedPdfKey); } catch (cleanupError) { console.warn("[Worker] PDF cleanup failed", cleanupError); } }
    const safe = userMessage(error);
    try { await updateJob(jobId, ownerId, { status: "failed", stage: "failed", errorCode: safe.code, errorMessage: safe.message, activeKey: null, heartbeatAt: new Date() }); } catch (persistError) { console.error("[Worker] Failed to persist error", persistError); }
    try { const job = await getJobForOwner(jobId, ownerId); if (job) await updateBookStatus(job.bookId, ownerId, "failed", "failed"); } catch (persistError) { console.error("[Worker] Failed to mark book failed", persistError); }
  } finally { running.delete(jobId); }
}

export function enqueueBookJob(jobId: number, ownerId: number) { void processBookJob(jobId, ownerId); }
