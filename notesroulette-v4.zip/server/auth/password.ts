import crypto from "node:crypto";

const KEY_LENGTH = 64;
const COST = 16384;

function scrypt(password: string, salt: Buffer, cost: number): Promise<Buffer> {
  return new Promise((resolve, reject) => crypto.scrypt(password, salt, KEY_LENGTH, { N: cost, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (error, key) => error ? reject(error) : resolve(key)));
}

/** Salted scrypt hash in the form `scrypt$cost$salt$hash` (no extra dependencies). */
export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, COST);
  return `scrypt$${COST}$${salt.toString("base64")}$${key.toString("base64")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [scheme, cost, saltB64, hashB64] = stored.split("$");
  if (scheme !== "scrypt" || !cost || !saltB64 || !hashB64) return false;
  const expected = Buffer.from(hashB64, "base64");
  const actual = await scrypt(password, Buffer.from(saltB64, "base64"), Number(cost));
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

/** Stable, fixed-length user id for an email address (the users.openId column holds 64 characters). */
export function emailToOpenId(email: string) {
  return `email_${crypto.createHash("sha256").update(email.trim().toLowerCase()).digest("hex").slice(0, 40)}`;
}

/** Tiny in-memory attempt limiter: at most `max` hits per key within `windowMs`. */
export class AttemptLimiter {
  private hits = new Map<string, number[]>();
  private max: number;
  private windowMs: number;
  constructor(max: number, windowMs: number) { this.max = max; this.windowMs = windowMs; }
  private recent(key: string, now: number) { const list = (this.hits.get(key) ?? []).filter(time => now - time < this.windowMs); this.hits.set(key, list); return list; }
  isBlocked(key: string, now = Date.now()) { return this.recent(key, now).length >= this.max; }
  record(key: string, now = Date.now()) { this.recent(key, now).push(now); }
  clear(key: string) { this.hits.delete(key); }
}
