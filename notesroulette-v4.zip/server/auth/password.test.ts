import { describe, expect, it } from "vitest";
import { AttemptLimiter, emailToOpenId, hashPassword, verifyPassword } from "./password";

describe("email/password auth helpers", () => {
  it("hashes with a random salt and verifies only the right password", async () => {
    const [a, b] = await Promise.all([hashPassword("correct horse battery"), hashPassword("correct horse battery")]);
    expect(a).not.toBe(b);
    expect(await verifyPassword("correct horse battery", a)).toBe(true);
    expect(await verifyPassword("wrong password", a)).toBe(false);
    expect(await verifyPassword("anything", "not-a-hash")).toBe(false);
  });
  it("derives a stable 64-char-safe id that ignores email case", () => {
    expect(emailToOpenId("A@b.com")).toBe(emailToOpenId(" a@B.com "));
    expect(emailToOpenId("a@b.com").length).toBeLessThanOrEqual(64);
  });
  it("blocks after too many attempts and recovers after the window", () => {
    const limiter = new AttemptLimiter(3, 1000);
    for (let i = 0; i < 3; i += 1) limiter.record("k", 0);
    expect(limiter.isBlocked("k", 500)).toBe(true);
    expect(limiter.isBlocked("k", 1500)).toBe(false);
    limiter.record("k", 2000); limiter.clear("k");
    expect(limiter.isBlocked("k", 2001)).toBe(false);
  });
});
