import crypto from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createBook, createJob, createPreferences, findBookByChecksum, getBookForOwner, getBooksWithLatestJobsForOwner, getExamSetForOwner, getFlashcardSetForOwner, getJobForOwner, getLatestJobForBook, getNotesForOwner, getQuizSetForOwner, getStudyChapters, getPasswordHash, getStudySourceForOwner, getUserByOpenId, insertPasswordHash, markBookDeleted, upsertUser, recordQuizAttempt, saveExamSet, saveFlashcardSet, saveQuizSet, updateFlashcardProgress, updateJob } from "./db";
import { storageDelete, storagePut } from "./storage";
import { enqueueBookJob } from "./jobs/worker";
import { validateSource, SourceValidationError } from "./documents/validation";
import type { BookPreferences } from "@shared/notes";
import type { QuizAnswer } from "@shared/study";
import { generateExam, generateFlashcards, generateQuiz } from "./study/generator";
import { answerDoubt } from "./study/chat";
import { AttemptLimiter, emailToOpenId, hashPassword, verifyPassword } from "./auth/password";
import { sdk } from "./_core/sdk";

const preferencesSchema = z.object({ detailLevel: z.enum(["concise", "balanced", "detailed"]).default("balanced"), visualIntensity: z.enum(["minimal", "balanced", "visual-heavy"]).default("balanced"), diagramPreference: z.enum(["automatic", "more", "fewer"]).default("automatic"), includeSources: z.boolean().default(true) });
const uploadSchema = z.object({ filename: z.string().min(1).max(255), mimeType: z.string().max(120).optional(), dataBase64: z.string().min(1).max(70_000_000), title: z.string().max(255).optional(), preferences: preferencesSchema.optional() });
const scopeSchema = z.object({ bookId: z.number().int().positive(), scope: z.enum(["book", "chapter"]), chapterTitle: z.string().min(1).max(255).optional() }).superRefine((value, context) => { if (value.scope === "chapter" && !value.chapterTitle) context.addIssue({ code: z.ZodIssueCode.custom, message: "Choose a chapter for this study mode." }); });
const chatInputSchema = z.object({ bookId: z.number().int().positive(), chapterTitle: z.string().min(1).max(255).optional(), question: z.string().trim().min(1).max(2000), history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(4000) })).max(20).default([]) });
const emailField = z.string().trim().toLowerCase().email("Enter a valid email address.").max(254);
const signupSchema = z.object({ email: emailField, password: z.string().min(8, "Use at least 8 characters.").max(200), name: z.string().trim().max(80).optional() });
const loginSchema = z.object({ email: emailField, password: z.string().min(1).max(200) });
const loginLimiter = new AttemptLimiter(8, 15 * 60_000);
const signupLimiter = new AttemptLimiter(10, 60 * 60_000);
async function startSession(ctx: { req: any; res: any }, openId: string, name: string) { const token = await sdk.createSessionToken(openId, { name, expiresInMs: ONE_YEAR_MS }); ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: ONE_YEAR_MS }); }
const studyRouter = router({
  chat: router({
    ask: protectedProcedure.input(chatInputSchema).mutation(async ({ ctx, input }) => {
      try { const source = await getStudySourceForOwner(input.bookId, ctx.user.id, input.chapterTitle); return await answerDoubt(source, input.history, input.question); }
      catch (error) { console.error("[Chat] Answer failed", error); throw new TRPCError({ code: "BAD_REQUEST", message: "I couldn't answer that right now. Make sure the notes finished processing, then try again." }); }
    }),
  }),
  chapters: protectedProcedure.input(z.object({ bookId: z.number().int().positive() })).query(({ ctx, input }) => getStudyChapters(input.bookId, ctx.user.id)),
  exam: router({
    get: protectedProcedure.input(scopeSchema).query(({ ctx, input }) => getExamSetForOwner(input.bookId, ctx.user.id, input.scope, input.chapterTitle)),
    generate: protectedProcedure.input(scopeSchema).mutation(async ({ ctx, input }) => { try { const cached = await getExamSetForOwner(input.bookId, ctx.user.id, input.scope, input.chapterTitle); if (cached) return cached; const source = await getStudySourceForOwner(input.bookId, ctx.user.id, input.chapterTitle); return saveExamSet(input.bookId, ctx.user.id, await generateExam(source, input.scope, input.chapterTitle)); } catch (error) { console.error("[Study] Exam generation failed", error); throw new TRPCError({ code: "BAD_REQUEST", message: "We couldn't generate exam material right now. Your book and notes are safe. Please try again." }); } }),
  }),
  quiz: router({
    get: protectedProcedure.input(z.object({ setId: z.number().int().positive() })).query(({ ctx, input }) => getQuizSetForOwner(input.setId, ctx.user.id)),
    generate: protectedProcedure.input(scopeSchema.safeExtend({ questionCount: z.union([z.literal(5), z.literal(10), z.literal(20)]), difficulty: z.enum(["easy", "medium", "hard", "mixed"]), mode: z.enum(["multiple-choice", "true-false", "mixed"]), nonce: z.number().int().nonnegative().default(0) })).mutation(async ({ ctx, input }) => { try { const source = await getStudySourceForOwner(input.bookId, ctx.user.id, input.chapterTitle); return saveQuizSet(input.bookId, ctx.user.id, await generateQuiz(source, input.scope, input.chapterTitle, input.questionCount, input.difficulty, input.mode, input.nonce)); } catch (error) { console.error("[Study] Quiz generation failed", error); throw new TRPCError({ code: "BAD_REQUEST", message: "We couldn't generate your quiz right now. Your book and notes are safe. Please try again." }); } }),
    submit: protectedProcedure.input(z.object({ setId: z.number().int().positive(), answers: z.array(z.object({ questionId: z.string(), selectedIndex: z.number().int().nullable() })) })).mutation(async ({ ctx, input }) => { const quiz = await getQuizSetForOwner(input.setId, ctx.user.id); if (!quiz) throw new TRPCError({ code: "NOT_FOUND", message: "Quiz not found." }); const answers = input.answers as QuizAnswer[]; const answerMap = new Map(answers.map(answer => [answer.questionId, answer.selectedIndex])); const correct = quiz.questions.filter(question => answerMap.get(question.id) === question.correctIndex); const weakTopics = [...new Set(quiz.questions.filter(question => answerMap.get(question.id) !== question.correctIndex).map(question => question.topic))].slice(0, 8); const attempt = { answers, score: correct.length, total: quiz.questions.length, percentage: quiz.questions.length ? Math.round((correct.length / quiz.questions.length) * 100) : 0, weakTopics }; return recordQuizAttempt(input.setId, ctx.user.id, attempt); }),
  }),
  flashcards: router({
    get: protectedProcedure.input(scopeSchema).query(({ ctx, input }) => getFlashcardSetForOwner(input.bookId, ctx.user.id, input.scope, input.chapterTitle)),
    generate: protectedProcedure.input(scopeSchema).mutation(async ({ ctx, input }) => { try { const cached = await getFlashcardSetForOwner(input.bookId, ctx.user.id, input.scope, input.chapterTitle); if (cached) return cached; const source = await getStudySourceForOwner(input.bookId, ctx.user.id, input.chapterTitle); return saveFlashcardSet(input.bookId, ctx.user.id, await generateFlashcards(source, input.scope, input.chapterTitle)); } catch (error) { console.error("[Study] Flashcard generation failed", error); throw new TRPCError({ code: "BAD_REQUEST", message: "We couldn't generate flashcards right now. Your book and notes are safe. Please try again." }); } }),
    progress: protectedProcedure.input(z.object({ setId: z.number().int().positive(), progress: z.record(z.string(), z.enum(["new", "know", "review"])) })).mutation(({ ctx, input }) => updateFlashcardProgress(input.setId, ctx.user.id, input.progress)),
  }),
});

export const appRouter = router({
  system: systemRouter,
  study: studyRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    signup: publicProcedure.input(signupSchema).mutation(async ({ ctx, input }) => {
      const ip = `ip:${ctx.req.ip ?? "unknown"}`;
      if (signupLimiter.isBlocked(ip)) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many sign-ups from this network. Please try again later." });
      signupLimiter.record(ip);
      const openId = emailToOpenId(input.email);
      try {
        if (await getUserByOpenId(openId)) throw new TRPCError({ code: "CONFLICT", message: "An account with this email already exists. Try signing in instead." });
        const name = input.name || input.email.split("@")[0] || "Student";
        await upsertUser({ openId, name, email: input.email, loginMethod: "email", lastSignedIn: new Date() });
        await insertPasswordHash(openId, await hashPassword(input.password));
        await startSession(ctx, openId, name);
        return { user: await getUserByOpenId(openId) ?? null };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[Auth] Sign-up failed", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "We couldn't create your account right now. Please try again." });
      }
    }),
    login: publicProcedure.input(loginSchema).mutation(async ({ ctx, input }) => {
      const key = `${ctx.req.ip ?? "unknown"}:${input.email}`;
      if (loginLimiter.isBlocked(key)) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Please wait a few minutes and try again." });
      const openId = emailToOpenId(input.email);
      try {
        const [hash, user] = await Promise.all([getPasswordHash(openId), getUserByOpenId(openId)]);
        const ok = Boolean(hash && user) && await verifyPassword(input.password, hash ?? "");
        if (!ok || !user) { loginLimiter.record(key); throw new TRPCError({ code: "UNAUTHORIZED", message: "Incorrect email or password." }); }
        loginLimiter.clear(key);
        await upsertUser({ openId, lastSignedIn: new Date() });
        await startSession(ctx, openId, user.name ?? "");
        return { user };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[Auth] Login failed", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "We couldn't sign you in right now. Please try again." });
      }
    }),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  books: router({
    list: protectedProcedure.query(({ ctx }) => getBooksWithLatestJobsForOwner(ctx.user.id)),
    get: protectedProcedure.input(z.object({ bookId: z.number().int().positive() })).query(({ ctx, input }) => getBookForOwner(input.bookId, ctx.user.id)),
    job: protectedProcedure.input(z.object({ jobId: z.number().int().positive() })).query(({ ctx, input }) => getJobForOwner(input.jobId, ctx.user.id)),
    latestJob: protectedProcedure.input(z.object({ bookId: z.number().int().positive() })).query(({ ctx, input }) => getLatestJobForBook(input.bookId, ctx.user.id)),
    notes: protectedProcedure.input(z.object({ bookId: z.number().int().positive() })).query(({ ctx, input }) => getNotesForOwner(input.bookId, ctx.user.id)),
    upload: protectedProcedure.input(uploadSchema).mutation(async ({ ctx, input }) => {
      const data = Buffer.from(input.dataBase64, "base64");
      const checksum = crypto.createHash("sha256").update(data).digest("hex");
      let storedKey: string | undefined;
      try {
        const validation = await validateSource({ filename: input.filename, declaredMime: input.mimeType, data });
        const existing = await findBookByChecksum(ctx.user.id, checksum);
        if (existing) {
          const existingJob = await getLatestJobForBook(existing.id, ctx.user.id);
          if (existingJob) return { book: existing, job: existingJob, duplicate: true };
        }
        const title = (input.title?.trim() || input.filename.replace(/\.[^.]+$/, "")).slice(0, 255);
        const stored = await storagePut(`users/${ctx.user.id}/books/${crypto.randomUUID()}-${input.filename.replace(/[^a-zA-Z0-9._-]/g, "_")}`, data, validation.detectedMime);
        storedKey = stored.key;
        const book = await createBook({ ownerId: ctx.user.id, ownerOpenId: ctx.user.openId, originalFilename: input.filename, title, mimeType: validation.detectedMime, sourceKind: validation.kind, fileSize: data.length, storageKey: stored.key, checksum, pageCount: validation.pageCount, status: "uploaded", notesStatus: "none" });
        const preferences = (input.preferences ?? { detailLevel: "balanced", visualIntensity: "balanced", diagramPreference: "automatic", includeSources: true }) as BookPreferences;
        await createPreferences(book.id, ctx.user.id, preferences);
        const job = await createJob(book.id, ctx.user.id);
        enqueueBookJob(job.id, ctx.user.id);
        return { book, job, duplicate: false };
      } catch (error) {
        if (storedKey) { try { await storageDelete(storedKey); } catch (cleanupError) { console.warn("[Books] Upload cleanup failed", cleanupError); } }
        if (error instanceof SourceValidationError) throw new TRPCError({ code: "BAD_REQUEST", message: error.message });
        console.error("[Books] Upload failed", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "We could not accept this upload. Please check the file and try again." });
      }
    }),
    retry: protectedProcedure.input(z.object({ jobId: z.number().int().positive() })).mutation(async ({ ctx, input }) => { const job = await getJobForOwner(input.jobId, ctx.user.id); if (!job) throw new TRPCError({ code: "NOT_FOUND", message: "Processing job not found." }); if (job.status !== "failed") throw new TRPCError({ code: "BAD_REQUEST", message: "Only failed jobs can be retried." }); if (job.attempts >= 3) throw new TRPCError({ code: "BAD_REQUEST", message: "This job has reached its retry limit." }); await updateJob(job.id, ctx.user.id, { status: "queued", stage: "uploading", progress: 0, errorCode: null, errorMessage: null, activeKey: `book-${job.bookId}` }); enqueueBookJob(job.id, ctx.user.id); return { success: true }; }),
    delete: protectedProcedure.input(z.object({ bookId: z.number().int().positive() })).mutation(async ({ ctx, input }) => { const book = await getBookForOwner(input.bookId, ctx.user.id); if (!book) throw new TRPCError({ code: "NOT_FOUND", message: "Book not found." }); await markBookDeleted(book.id, ctx.user.id); await storageDelete(book.storageKey); return { success: true }; }),
  }),
});

export type AppRouter = typeof appRouter;
