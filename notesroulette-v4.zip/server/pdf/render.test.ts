import { describe, expect, it } from "vitest";
import { renderNotesPdf } from "./render";
import type { GeneratedNotes } from "../../shared/notes";

const baseNotes: GeneratedNotes = { title: "A study source", subject: "History", overview: "A source-grounded overview.", generationMode: "extractive", sourceWarnings: [], findings: [], sections: [{ id: "one", chapterTitle: "Chapter one", title: "Foundations", summary: "The source explains the foundations.", bullets: ["A key source-backed point."], keyTerms: ["foundations"], sourceRefs: [{ startPage: 1, endPage: 2, label: "pp. 1–2" }] }], visuals: [] };

describe("notes PDF renderer", () => {
  it("creates a non-empty PDF with source-grounded note content", async () => {
    const pdf = await renderNotesPdf(baseNotes);
    expect(pdf.subarray(0, 5).toString()).toBe("%PDF-");
    expect(pdf.length).toBeGreaterThan(1000);
  });

  it("draws concept-map and flow diagrams into the PDF", async () => {
    const withVisuals: GeneratedNotes = {
      ...baseNotes,
      sections: [...baseNotes.sections, { id: "two", chapterTitle: "Chapter two", title: "Consequences", summary: "The source explains the consequences.", bullets: ["First effect.", "Second effect."], keyTerms: ["treaty", "revolution", "empire"], sourceRefs: [{ startPage: 3, endPage: 4, label: "pp. 3–4" }] }],
      visuals: [
        { id: "visual-1", title: "Chapter one at a glance", chapterTitle: "Chapter one", strategy: "generated", kind: "concept-map", centre: "Chapter one", nodes: ["foundations", "origins", "context", "actors", "timeline", "legacy"], description: "A concept map.", sourceRefs: [{ startPage: 1, endPage: 2, label: "pp. 1–2" }] },
        { id: "visual-2", title: "Chapter two: how it fits together", chapterTitle: "Chapter two", strategy: "generated", kind: "flow", centre: "Chapter two", nodes: ["treaty", "revolution", "empire", "collapse"], description: "A flow.", sourceRefs: [{ startPage: 3, endPage: 4, label: "pp. 3–4" }] },
        { id: "visual-3", title: "Legacy visual without a chapter", strategy: "generated", kind: "concept-map", description: "Falls back to the visual revision page.", sourceRefs: [] },
      ],
    };
    const plain = await renderNotesPdf(baseNotes);
    const pdf = await renderNotesPdf(withVisuals);
    expect(pdf.subarray(0, 5).toString()).toBe("%PDF-");
    expect(pdf.length).toBeGreaterThan(plain.length);
  });
});