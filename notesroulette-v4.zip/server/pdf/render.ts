import PDFDocument from "pdfkit";
import type { GeneratedNotes, NoteVisual, SourceRef } from "@shared/notes";

type Doc = PDFKit.PDFDocument;

const PAGE_W = 595;
const PAGE_H = 842;
const MARGIN = 48;
const CONTENT_W = PAGE_W - MARGIN * 2;

const INK = "#17202A";
const MUTED = "#46515B";
const FAINT = "#6F7B84";
const LIME = "#D7F36B";
const CORAL = "#FF765D";
const SKY = "#9BD5FF";
const PAPER = "#F7F7F1";
const PALETTE = [CORAL, SKY, LIME, "#F5B3E8", "#FFD37A", "#B8F0D6"];

function safeText(value: string) { return value.replace(/\s+/g, " ").trim(); }
function clip(value: string, max: number) { const text = safeText(value); return text.length > max ? `${text.slice(0, max - 1)}…` : text; }
function colour(index: number) { return PALETTE[index % PALETTE.length] ?? CORAL; }
function refLabel(refs: SourceRef[]) { return refs.map(ref => ref.label || `pp. ${ref.startPage}–${ref.endPage}`).join(", "); }

// ---------- Diagram drawing (pure PDFKit vectors; no rasterisation) ----------

function visualHeight(visual: NoteVisual) {
  const nodes = (visual.nodes ?? []).slice(0, 6);
  if (visual.kind === "flow" && nodes.length) return 56 + Math.ceil(nodes.length / 3) * 84 + 14;
  return 272;
}

function ensureSpace(doc: Doc, height: number) {
  if (doc.y + height > PAGE_H - doc.page.margins.bottom) { doc.addPage(); }
}

function drawConceptMap(doc: Doc, centre: string, nodes: string[], x: number, y: number, w: number, h: number) {
  const cx = x + w / 2; const cy = y + h / 2; const rx = w / 2 - 62; const ry = h / 2 - 20;
  const positions = nodes.map((_, index) => { const angle = -Math.PI / 2 + (index / Math.max(nodes.length, 1)) * Math.PI * 2; return { px: cx + rx * Math.cos(angle), py: cy + ry * Math.sin(angle) }; });
  positions.forEach(({ px, py }, index) => { doc.strokeColor(colour(index)).lineWidth(2.5).moveTo(cx, cy).lineTo(px, py).stroke(); });
  doc.roundedRect(cx - 78, cy - 22, 156, 44, 12).fill(INK);
  doc.fillColor(LIME).font("Helvetica-Bold").fontSize(10).text(clip(centre, 26), cx - 74, cy - 6, { width: 148, align: "center", lineBreak: false });
  positions.forEach(({ px, py }, index) => {
    doc.roundedRect(px - 60, py - 16, 120, 32, 10).fill(colour(index));
    doc.fillColor(INK).font("Helvetica-Bold").fontSize(8.5).text(clip(nodes[index] ?? "", 22), px - 56, py - 5, { width: 112, align: "center", lineBreak: false });
  });
  if (!nodes.length) doc.fillColor(FAINT).font("Helvetica").fontSize(9).text("Key terms were not detected for this chapter.", x, y + h - 14, { width: w, align: "center", lineBreak: false });
}

function drawFlow(doc: Doc, nodes: string[], x: number, y: number, w: number) {
  const perRow = 3; const gap = 34; const boxW = (w - gap * (perRow - 1)) / perRow; const boxH = 40; const pitch = 84;
  nodes.forEach((node, index) => {
    const row = Math.floor(index / perRow); const col = index % perRow;
    const bx = x + col * (boxW + gap); const by = y + row * pitch;
    doc.roundedRect(bx, by, boxW, boxH, 10).fill(colour(index));
    doc.fillColor(INK).font("Helvetica-Bold").fontSize(7).text(String(index + 1).padStart(2, "0"), bx + 8, by + 6, { lineBreak: false });
    doc.font("Helvetica-Bold").fontSize(8.5).text(clip(node, 24), bx + 6, by + 17, { width: boxW - 12, align: "center", lineBreak: false });
    if (index === nodes.length - 1) return;
    doc.strokeColor(INK).lineWidth(2);
    if (col < perRow - 1) {
      const ax = bx + boxW + 4; const ay = by + boxH / 2; const ex = ax + gap - 8;
      doc.moveTo(ax, ay).lineTo(ex, ay).stroke();
      doc.moveTo(ex, ay).lineTo(ex - 6, ay - 4).lineTo(ex - 6, ay + 4).fill(INK);
    } else {
      const sx = bx + boxW / 2; const sy = by + boxH + 4; const midY = by + boxH + (pitch - boxH) / 2; const ex = x + boxW / 2; const ey = by + pitch - 4;
      doc.moveTo(sx, sy).lineTo(sx, midY).lineTo(ex, midY).lineTo(ex, ey).stroke();
      doc.moveTo(ex, ey).lineTo(ex - 4, ey - 6).lineTo(ex + 4, ey - 6).fill(INK);
    }
  });
}

function drawVisual(doc: Doc, visual: NoteVisual) {
  const height = visualHeight(visual);
  ensureSpace(doc, height + 40);
  const x = MARGIN; const top = doc.y; const width = CONTENT_W;
  const nodes = (visual.nodes ?? []).slice(0, 6);
  doc.save();
  doc.roundedRect(x, top, width, height, 18).fill(PAPER);
  doc.fillColor(CORAL).font("Helvetica-Bold").fontSize(8).text(visual.kind.replace("-", " ").toUpperCase(), x + 18, top + 14, { width: width - 36, lineBreak: false, characterSpacing: 1 });
  doc.fillColor(INK).font("Helvetica-Bold").fontSize(12).text(clip(visual.title, 72), x + 18, top + 26, { width: width - 36, lineBreak: false });
  if (visual.kind === "flow" && nodes.length) drawFlow(doc, nodes, x + 18, top + 56, width - 36);
  else drawConceptMap(doc, visual.centre ?? visual.title, nodes, x + 18, top + 50, width - 36, height - 62);
  doc.restore();
  doc.x = MARGIN;
  doc.y = top + height + 6;
  const caption = [safeText(visual.description), visual.sourceRefs.length ? `Source: ${refLabel(visual.sourceRefs)}` : ""].filter(Boolean).join("  ·  ");
  doc.fillColor(FAINT).font("Helvetica").fontSize(8).text(clip(caption, 220), MARGIN, doc.y, { width: CONTENT_W, lineGap: 2 });
  doc.moveDown(1);
}

// ---------- Document ----------

export async function renderNotesPdf(notes: GeneratedNotes): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: "A4", margin: MARGIN, info: { Title: notes.title, Author: "Notes Roulette" } });
    const chunks: Buffer[] = [];
    doc.on("data", chunk => chunks.push(Buffer.from(chunk)));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);

    try {
      // Cover
      doc.rect(0, 0, PAGE_W, PAGE_H).fill(INK);
      doc.fillColor(LIME).font("Helvetica-Bold").fontSize(15).text("NOTES ROULETTE", MARGIN, 76, { characterSpacing: 2 });
      doc.fillColor("#FFFFFF").font("Helvetica-Bold").fontSize(34).text(safeText(notes.title).slice(0, 110), MARGIN, 180, { width: 470 });
      doc.fillColor(SKY).font("Helvetica").fontSize(16).text(notes.subject, MARGIN, 310);
      doc.fillColor("#FFFFFF").fontSize(11).text("Source-grounded study notes", MARGIN, 740);
      doc.fillColor(LIME).fontSize(10).text(`${notes.sections.length} study sections · ${notes.visuals.length} diagram${notes.visuals.length === 1 ? "" : "s"} · ${notes.generationMode === "ai" ? "AI analysed" : "source-extractive fallback"}`, MARGIN, 760);
      doc.addPage();

      // Contents + overview
      doc.fillColor(INK).font("Helvetica-Bold").fontSize(24).text("Contents");
      doc.moveDown(0.6);
      notes.sections.forEach((section, index) => doc.font("Helvetica").fontSize(11).fillColor(MUTED).text(`${String(index + 1).padStart(2, "0")}  ${safeText(section.title).slice(0, 90)}`));
      if (notes.visuals.length) { doc.moveDown(0.4); doc.font("Helvetica").fontSize(10).fillColor(FAINT).text(`Includes ${notes.visuals.length} source-grounded diagram${notes.visuals.length === 1 ? "" : "s"} placed alongside the chapters they summarise.`); }
      doc.moveDown(1.2);
      doc.fillColor(CORAL).font("Helvetica-Bold").fontSize(11).text("AT A GLANCE");
      doc.moveDown(0.3);
      doc.fillColor(INK).font("Helvetica").fontSize(12).text(safeText(notes.overview), { lineGap: 5 });

      // Chapters, each followed by its diagram(s)
      const drawnVisuals = new Set<string>();
      for (const [index, section] of notes.sections.entries()) {
        doc.addPage();
        doc.fillColor(CORAL).font("Helvetica-Bold").fontSize(10).text(`CHAPTER ${index + 1}`);
        doc.moveDown(0.25);
        doc.fillColor(INK).font("Helvetica-Bold").fontSize(22).text(safeText(section.title).slice(0, 100));
        doc.moveDown(0.45);
        doc.fillColor(MUTED).font("Helvetica").fontSize(12).text(safeText(section.summary), { lineGap: 5 });
        doc.moveDown(0.7);
        section.bullets.forEach(bullet => { doc.fillColor(INK).font("Helvetica-Bold").fontSize(12).text("•", { continued: true }); doc.font("Helvetica").text(` ${safeText(bullet)}`, { lineGap: 4 }); doc.moveDown(0.2); });
        if (section.keyTerms.length) { doc.moveDown(0.8); doc.fillColor(INK).font("Helvetica-Bold").fontSize(10).text("KEY TERMS"); doc.moveDown(0.25); doc.fillColor(MUTED).font("Helvetica").fontSize(10).text(section.keyTerms.join("  ·  ")); }
        if (section.sourceRefs.length) { doc.moveDown(1); doc.fillColor(FAINT).fontSize(9).text(`Source: ${refLabel(section.sourceRefs)}`); }
        const chapterVisuals = notes.visuals.filter(visual => !drawnVisuals.has(visual.id) && (visual.chapterTitle ? visual.chapterTitle === section.chapterTitle : false));
        if (chapterVisuals.length) {
          doc.moveDown(1.2);
          for (const visual of chapterVisuals) { drawnVisuals.add(visual.id); drawVisual(doc, visual); }
        }
      }

      // Any visuals not tied to a chapter (older notes or custom strategies)
      const remaining = notes.visuals.filter(visual => !drawnVisuals.has(visual.id));
      if (remaining.length) {
        doc.addPage();
        doc.fillColor(CORAL).font("Helvetica-Bold").fontSize(10).text("VISUAL REVISION");
        doc.moveDown(0.25);
        doc.fillColor(INK).font("Helvetica-Bold").fontSize(22).text("Diagrams");
        doc.moveDown(1);
        for (const visual of remaining) drawVisual(doc, visual);
      }

      // Quality notes
      const unresolved = notes.findings.filter(finding => !finding.resolved);
      if (unresolved.length || notes.sourceWarnings.length) {
        doc.addPage();
        doc.fillColor(CORAL).font("Helvetica-Bold").fontSize(10).text("QUALITY CHECK");
        doc.moveDown(0.25);
        doc.fillColor(INK).font("Helvetica-Bold").fontSize(22).text("Read with care");
        doc.moveDown(0.6);
        for (const finding of unresolved) { doc.fillColor(INK).font("Helvetica-Bold").fontSize(10).text(`${finding.severity.toUpperCase()} · ${finding.category}`); doc.fillColor(MUTED).font("Helvetica").fontSize(10).text(safeText(finding.message), { lineGap: 3 }); doc.moveDown(0.5); }
        for (const warning of notes.sourceWarnings) { doc.fillColor(INK).font("Helvetica-Bold").fontSize(10).text("EXTRACTION"); doc.fillColor(MUTED).font("Helvetica").fontSize(10).text(safeText(warning), { lineGap: 3 }); doc.moveDown(0.5); }
      }

      doc.end();
    } catch (error) {
      reject(error instanceof Error ? error : new Error(String(error)));
    }
  });
}