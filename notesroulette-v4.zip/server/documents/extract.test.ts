import { describe, expect, it } from "vitest";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { extractDocument } from "./extract";

describe("document extraction", () => {
  it("extracts page-associated text from a real PDF", async () => {
    const pdf = await PDFDocument.create();
    const page = pdf.addPage();
    const font = await pdf.embedFont(StandardFonts.Helvetica);
    page.drawText("CHAPTER 1 Foundations\nA source-backed idea.", { x: 60, y: 730, size: 16, font, color: rgb(0, 0, 0) });
    const result = await extractDocument({ data: Buffer.from(await pdf.save()), filename: "source.pdf", mime: "application/pdf", title: "Source" });
    expect(result.pageCount).toBe(1);
    expect(result.pages[0]?.text).toContain("CHAPTER 1");
    expect(result.pages[0]?.pageNumber).toBe(1);
    expect(result.chapters.length).toBeGreaterThan(0);
  });
});
