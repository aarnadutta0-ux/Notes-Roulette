import { describe, expect, it } from "vitest";
import { PDFDocument } from "pdf-lib";
import { cleanPages } from "./clean";
import { chunkChapters } from "./chunk";
import { detectStructure } from "./structure";
import { SourceValidationError, validateSource } from "./validation";

describe("document pipeline primitives", () => {
  it("rejects an empty or renamed file before parsing", async () => {
    await expect(validateSource({ filename: "book.pdf", data: Buffer.alloc(0) })).rejects.toMatchObject({ code: "EMPTY_FILE" });
    await expect(validateSource({ filename: "book.pdf", data: Buffer.from("not a pdf") })).rejects.toBeInstanceOf(SourceValidationError);
  });

  it("validates a real PDF signature and page count", async () => {
    const pdf = await PDFDocument.create();
    pdf.addPage();
    const result = await validateSource({ filename: "book.pdf", declaredMime: "application/pdf", data: Buffer.from(await pdf.save()) });
    expect(result.kind).toBe("pdf");
    expect(result.pageCount).toBe(1);
  });

  it("removes contextual repeated noise while repairing hyphenation", () => {
    const pages = [1, 2, 3].map(pageNumber => ({ pageNumber, text: `BOOK TITLE\nA know-\nledge system\n${pageNumber}`, confidence: 1, sourceKind: "pdf" as const, blocks: [], images: [] }));
    const cleaned = cleanPages(pages);
    expect(cleaned[0].text).toContain("knowledge system");
    expect(cleaned[1].text).not.toContain("BOOK TITLE");
    expect(cleaned[2].text).not.toMatch(/^3$/m);
  });

  it("detects chapters and preserves bounded source chunks", () => {
    const structure = detectStructure([{ pageNumber: 1, text: "CHAPTER 1\nFoundations\nA definition and a useful explanation.", confidence: 1, sourceKind: "pdf", blocks: [], images: [] }, { pageNumber: 2, text: "CHAPTER 2\nMethods\nA second explanation.", confidence: 1, sourceKind: "pdf", blocks: [], images: [] }], "Study source");
    expect(structure.chapters.length).toBeGreaterThanOrEqual(2);
    const chunks = chunkChapters(structure.chapters, 35, 5);
    expect(chunks.length).toBeGreaterThan(1);
    expect(chunks.every(chunk => chunk.text.length <= 35)).toBe(true);
    expect(chunks.every(chunk => chunk.startPage >= 1 && chunk.endPage <= 2)).toBe(true);
  });
});
