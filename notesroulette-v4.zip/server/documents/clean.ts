import type { DocumentPage } from "@shared/document";

const normalizeLine = (line: string) => line.replace(/[\u00a0\t ]+/g, " ").trim();

function repeatedNoise(pages: DocumentPage[]) {
  const counts = new Map<string, number>();
  for (const page of pages) {
    const lines = page.text.split(/\r?\n/).map(normalizeLine).filter(Boolean);
    for (const line of [lines[0], lines.at(-1)]) {
      if (line && line.length < 120) counts.set(line, (counts.get(line) ?? 0) + 1);
    }
  }
  return new Set([...counts.entries()].filter(([, count]) => count >= 3).map(([line]) => line));
}

export function cleanPages(pages: DocumentPage[]) {
  const repeated = repeatedNoise(pages);
  return pages.map(page => {
    const lines = page.text.split(/\r?\n/).map(normalizeLine).filter(Boolean);
    const kept: string[] = [];
    for (const line of lines) {
      if (repeated.has(line)) continue;
      if (/^(copyright|all rights reserved|advertisement|www\.|index|references?)$/i.test(line)) continue;
      if (/^\d{1,4}$/.test(line) && line.length <= 4) continue;
      kept.push(line);
    }
    let text = kept.join("\n").replace(/([A-Za-z])[-‐‑]\s+([a-z])/g, "$1$2");
    text = text.replace(/\n{3,}/g, "\n\n").trim();
    return { ...page, text, rawText: page.rawText ?? page.text };
  });
}
