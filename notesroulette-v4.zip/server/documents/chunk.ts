import type { DocumentChapter, DocumentChunk } from "@shared/document";

export function chunkChapters(chapters: DocumentChapter[], maxCharacters = 6500, overlap = 600): DocumentChunk[] {
  const chunks: DocumentChunk[] = [];
  for (const chapter of chapters) {
    const text = chapter.text.trim();
    if (!text) continue;
    let offset = 0;
    let index = 0;
    while (offset < text.length) {
      const end = Math.min(text.length, offset + maxCharacters);
      const piece = text.slice(offset, end).trim();
      if (piece) {
        const ratioStart = offset / Math.max(text.length, 1);
        const ratioEnd = end / Math.max(text.length, 1);
        chunks.push({ id: `${chapter.id}-chunk-${index + 1}`, chapterId: chapter.id, chapterTitle: chapter.title, startPage: Math.max(chapter.startPage, Math.floor(chapter.startPage + ratioStart * (chapter.endPage - chapter.startPage))), endPage: Math.min(chapter.endPage, Math.ceil(chapter.startPage + ratioEnd * (chapter.endPage - chapter.startPage))), text: piece, index });
      }
      if (end >= text.length) break;
      offset = Math.max(end - overlap, offset + 1);
      index += 1;
    }
  }
  return chunks;
}
