import type { DocumentChapter, DocumentPage, DocumentSection } from "@shared/document";

const chapterPattern = /^(chapter\s+\d+|unit\s+\d+|part\s+[ivx\d]+|\d+[.)]\s+[^.!?]{3,100})$/i;
const sectionPattern = /^(\d+(?:\.\d+){1,2}[.)]?\s+|[A-Z][A-Z\s]{5,80}$)/;

function titleFromPages(pages: DocumentPage[]) {
  const first = pages.flatMap(page => page.text.split(/\r?\n/).map(line => line.trim())).find(line => line.length >= 4 && line.length <= 120);
  return first || "Untitled source";
}

export function detectStructure(pages: DocumentPage[], fallbackTitle?: string) {
  const chapters: DocumentChapter[] = [];
  let current: DocumentChapter | null = null;
  const ensureChapter = (pageNumber: number) => {
    if (!current) {
      current = { id: "chapter-1", title: "Source overview", startPage: pageNumber, endPage: pageNumber, sections: [], text: "" };
      chapters.push(current);
    }
    return current;
  };

  for (const page of pages) {
    const chapter = ensureChapter(page.pageNumber);
    chapter.endPage = page.pageNumber;
    const lines = page.text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
    for (const line of lines) {
      if (chapterPattern.test(line) && line.length <= 110) {
        if (chapter.text.trim() || chapters.length > 1) {
          current = { id: `chapter-${chapters.length + 1}`, title: line.replace(/^[\d.)\s]+/, "").trim(), startPage: page.pageNumber, endPage: page.pageNumber, sections: [], text: "" };
          chapters.push(current);
        } else {
          chapter.title = line.replace(/^[\d.)\s]+/, "").trim();
        }
        continue;
      }
      const active = ensureChapter(page.pageNumber);
      active.text += `${line}\n`;
      const isSection = sectionPattern.test(line) && line.length <= 110 && !/[.!?]$/.test(line);
      if (isSection) {
        const level = /^\d+\.\d+\.\d+/.test(line) ? 3 : /^\d+\.\d+/.test(line) ? 2 : 2;
        const section: DocumentSection = { id: `${active.id}-section-${active.sections.length + 1}`, title: line.replace(/^[\d.)\s]+/, "").trim(), level: level as 2 | 3, startPage: page.pageNumber, endPage: page.pageNumber, text: "", parentId: active.id };
        active.sections.push(section);
      } else {
        const section = active.sections.at(-1);
        if (section) { section.text += `${line}\n`; section.endPage = page.pageNumber; }
      }
    }
  }

  for (const chapter of chapters) {
    chapter.text = chapter.text.trim();
    if (!chapter.sections.length && chapter.text) chapter.sections.push({ id: `${chapter.id}-section-1`, title: chapter.title, level: 2, startPage: chapter.startPage, endPage: chapter.endPage, text: chapter.text, parentId: chapter.id });
  }
  return { title: fallbackTitle?.trim() || titleFromPages(pages), chapters: chapters.filter(chapter => chapter.text.length > 0 || chapter.sections.length > 0) };
}
