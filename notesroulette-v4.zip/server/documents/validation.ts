import { fileTypeFromBuffer } from "file-type";
import { PDFDocument } from "pdf-lib";
import type { SupportedSourceKind } from "@shared/document";

export const MAX_FILE_BYTES = 50 * 1024 * 1024;
export const MAX_PAGES = 500;

const EXTENSIONS: Record<string, SupportedSourceKind> = {
  ".pdf": "pdf",
  ".docx": "docx",
  ".epub": "epub",
  ".jpg": "image",
  ".jpeg": "image",
  ".png": "image",
};

export class SourceValidationError extends Error {
  constructor(public code: string, message: string) {
    super(message);
    this.name = "SourceValidationError";
  }
}

function extensionOf(filename: string) {
  const dot = filename.lastIndexOf(".");
  return dot >= 0 ? filename.slice(dot).toLowerCase() : "";
}

export async function validateSource(input: {
  filename: string;
  declaredMime?: string;
  data: Buffer;
}) {
  const extension = extensionOf(input.filename);
  const kind = EXTENSIONS[extension];
  if (!kind) throw new SourceValidationError("UNSUPPORTED_FILE", "This file type is not supported. Use PDF, EPUB, DOCX, JPG, JPEG or PNG.");
  if (!input.data.length) throw new SourceValidationError("EMPTY_FILE", "The uploaded file is empty.");
  if (input.data.length > MAX_FILE_BYTES) throw new SourceValidationError("FILE_TOO_LARGE", "This file is larger than the 50 MB limit.");

  const detected = await fileTypeFromBuffer(input.data);
  const allowedMime = new Set(kind === "pdf" ? ["application/pdf"] : kind === "docx" || kind === "epub" ? ["application/zip", "application/epub+zip"] : ["image/jpeg", "image/png"]);
  if (!detected || !allowedMime.has(detected.mime)) {
    throw new SourceValidationError("INVALID_SIGNATURE", "The file contents do not match a supported document format.");
  }
  if (input.declaredMime && input.declaredMime !== "application/octet-stream" && input.declaredMime !== detected.mime && !(kind === "docx" && input.declaredMime.includes("word")) && !(kind === "epub" && input.declaredMime.includes("epub"))) {
    throw new SourceValidationError("MIME_MISMATCH", "The browser-reported file type does not match the file contents.");
  }

  let pageCount = kind === "image" ? 1 : 0;
  if (kind === "pdf") {
    try {
      const pdf = await PDFDocument.load(input.data, { ignoreEncryption: false, throwOnInvalidObject: true });
      pageCount = pdf.getPageCount();
    } catch {
      throw new SourceValidationError("CORRUPTED_FILE", "This PDF could not be read. Please try a different copy.");
    }
    if (pageCount > MAX_PAGES) throw new SourceValidationError("PAGE_LIMIT", `This document has ${pageCount} pages. Notes Roulette supports up to ${MAX_PAGES} pages.`);
  }
  return { kind, extension, detectedMime: detected.mime, pageCount };
}
