import { spawn } from "node:child_process";

export class OcrUnavailableError extends Error {
  constructor() { super("OCR is not available in this runtime. Upload a text-based document or configure Tesseract OCR."); this.name = "OcrUnavailableError"; }
}

export async function ocrImage(data: Buffer): Promise<{ text: string; confidence: number }> {
  return new Promise((resolve, reject) => {
    const child = spawn("tesseract", ["stdin", "stdout", "--psm", "6"], { stdio: ["pipe", "pipe", "pipe"] });
    let output = "";
    let error = "";
    child.stdout.on("data", chunk => { output += chunk.toString(); });
    child.stderr.on("data", chunk => { error += chunk.toString(); });
    child.once("error", () => reject(new OcrUnavailableError()));
    child.once("close", code => {
      if (code !== 0) return reject(new Error(error || "OCR failed"));
      resolve({ text: output.trim(), confidence: output.trim() ? 0.78 : 0.2 });
    });
    child.stdin.end(data);
  });
}
