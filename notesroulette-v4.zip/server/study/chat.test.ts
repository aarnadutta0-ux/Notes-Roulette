import { describe, expect, it } from "vitest";
import { extractiveAnswer, normaliseHistory, pickRelevantChunks, questionTerms } from "./chat";
import type { DocumentChunk } from "../../shared/document";

const chunk = (id: string, title: string, startPage: number, text: string, index: number): DocumentChunk => ({ id, chapterId: id, chapterTitle: title, startPage, endPage: startPage + 1, text, index });
const chunks = [chunk("a", "Cells", 1, "Mitochondria produce ATP through cellular respiration in the cell.", 0), chunk("b", "Genetics", 3, "DNA replication copies the genome before every cell division happens.", 1), chunk("c", "Ecology", 5, "Food webs describe energy transfer between producers and consumers.", 2)];

describe("study chat helpers", () => {
  it("drops filler words from questions", () => { expect(questionTerms("What does the mitochondria do?")).toEqual(["mitochondria"]); });
  it("puts the most relevant chunk in when the budget is tight, keeping reading order", () => {
    const picked = pickRelevantChunks(chunks, "how is DNA copied during replication", 70);
    expect(picked.map(item => item.id)).toEqual(["b"]);
    expect(pickRelevantChunks(chunks, "energy", 100000).map(item => item.id)).toEqual(["a", "b", "c"]);
  });
  it("cleans history into user/assistant alternation that starts and ends correctly", () => {
    const turns = normaliseHistory([{ role: "assistant", content: "stray" }, { role: "user", content: "q1" }, { role: "user", content: "q1b" }, { role: "assistant", content: "a1" }, { role: "user", content: "dangling" }]);
    expect(turns).toEqual([{ role: "user", content: "q1\nq1b" }, { role: "assistant", content: "a1" }]);
  });
  it("falls back to passages with page references, or says nothing matched", () => {
    const hit = extractiveAnswer(chunks, "mitochondria ATP respiration");
    expect(hit.mode).toBe("extractive"); expect(hit.sourceRefs[0]?.startPage).toBe(1); expect(hit.answer).toContain("Mitochondria");
    expect(extractiveAnswer(chunks, "quantum chromodynamics").sourceRefs).toEqual([]);
  });
});
