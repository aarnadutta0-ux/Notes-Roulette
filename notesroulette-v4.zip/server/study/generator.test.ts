import { describe, expect, it } from "vitest";
import { fallbackCards, fallbackExam, fallbackQuiz } from "./generator";
import type { DocumentChunk } from "../../shared/document";

const sourceChunks: DocumentChunk[] = [{ id: "chunk-1", chapterId: "Chapter 1", chapterTitle: "Chapter 1", startPage: 4, endPage: 5, index: 0, text: "Demand elasticity measures the responsiveness of quantity demanded to a change in price. It is useful for understanding revenue and consumer response." }];

describe("source-grounded study generators", () => {
  it("creates revealable exam prompts with source pages", () => {
    const material = fallbackExam({ title: "Economics", subject: "Economics", chunks: sourceChunks }, "chapter", "Chapter 1");
    expect(material.questions.length).toBeGreaterThan(0);
    expect(material.questions.every(question => question.answer && question.sourceRefs[0]?.startPage === 4)).toBe(true);
  });

  it("creates quiz questions with one valid answer and source grounding", () => {
    const material = fallbackQuiz({ title: "Economics", subject: "Economics", chunks: sourceChunks }, "book", undefined, 5, "mixed", "mixed");
    expect(material.questions).toHaveLength(5);
    expect(material.questions.every(question => question.correctIndex >= 0 && question.correctIndex < question.options.length && question.sourceRefs.length > 0)).toBe(true);
  });

  it("creates concise flashcards with persisted-ready states and page references", () => {
    const material = fallbackCards({ title: "Economics", subject: "Economics", chunks: sourceChunks }, "book");
    expect(material.cards.length).toBeGreaterThan(0);
    expect(material.cards[0].state).toBe("new");
    expect(material.cards[0].sourceRefs[0]).toMatchObject({ startPage: 4, endPage: 5 });
  });
});
