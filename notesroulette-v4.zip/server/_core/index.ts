import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { sdk } from "./sdk";
import { getBookForOwner, getPdfKeyForOwner } from "../db";
import { storageRead } from "../storage";

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.set("trust proxy", 1);
  app.use(express.json({ limit: "70mb" }));
  app.use(express.urlencoded({ limit: "70mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => { res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript()); });
  app.get("/api/books/:bookId/pdf", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      const bookId = Number(req.params.bookId);
      if (!Number.isInteger(bookId) || bookId <= 0) return res.status(400).send("Invalid book");
      const book = await getBookForOwner(bookId, user.id);
      if (!book) return res.status(404).send("Not found");
      const key = await getPdfKeyForOwner(bookId, user.id);
      if (!key) return res.status(404).send("PDF not ready");
      const data = await storageRead(key);
      res.set({ "Content-Type": "application/pdf", "Content-Length": String(data.length), "Cache-Control": "private, no-store", "Content-Disposition": `inline; filename="${book.title.replace(/[^a-z0-9 _-]/gi, "_")}.pdf"` });
      return res.send(data);
    } catch { return res.status(401).send("Not authorized"); }
  });
  registerOAuthRoutes(app);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  if (process.env.NODE_ENV === "development") await setupVite(app, server); else serveStatic(app);
  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}
startServer().catch(error => { console.error(error); process.exit(1); });
