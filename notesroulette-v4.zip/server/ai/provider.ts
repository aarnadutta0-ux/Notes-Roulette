import { invokeLLM } from "../_core/llm";
import { ENV } from "../_core/env";

export type ProviderName = "managed" | "openai" | "gemini" | "anthropic";
export type ProviderMessage = { role: "system" | "user" | "assistant"; content: string };
export type StructuredRequest = { messages: ProviderMessage[]; schema: Record<string, unknown>; schemaName: string; maxTokens?: number };

function configuredProvider(): ProviderName | null {
  const configured = process.env.NOTES_PROVIDER as ProviderName | undefined;
  if (configured === "openai" && process.env.OPENAI_API_KEY) return configured;
  if (configured === "gemini" && process.env.GEMINI_API_KEY) return configured;
  if (configured === "anthropic" && process.env.ANTHROPIC_API_KEY) return configured;
  if (ENV.forgeApiKey) return "managed";
  return null;
}

async function invokeExternal(provider: Exclude<ProviderName, "managed">, request: StructuredRequest) {
  if (provider === "openai") {
    const base = (process.env.OPENAI_API_BASE || "https://api.openai.com/v1").replace(/\/$/, "");
    const response = await fetch(`${base}/chat/completions`, { method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${process.env.OPENAI_API_KEY}` }, body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-4o-mini", messages: request.messages, response_format: { type: "json_schema", json_schema: { name: request.schemaName, strict: true, schema: request.schema } }, max_tokens: request.maxTokens ?? 2200 }) });
    if (!response.ok) throw new Error(`OpenAI provider failed (${response.status})`);
    const json = await response.json() as { choices?: Array<{ message?: { content?: string } }> };
    return json.choices?.[0]?.message?.content ?? "";
  }
  if (provider === "gemini") {
    const model = process.env.GEMINI_MODEL || "gemini-2.0-flash";
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: request.messages.map(message => `${message.role.toUpperCase()}: ${message.content}`).join("\n\n") }] }], generationConfig: { responseMimeType: "application/json", responseSchema: request.schema, maxOutputTokens: request.maxTokens ?? 2200 } }) });
    if (!response.ok) throw new Error(`Gemini provider failed (${response.status})`);
    const json = await response.json() as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
    return json.candidates?.[0]?.content?.parts?.map(part => part.text ?? "").join("") ?? "";
  }
  const response = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY ?? "", "anthropic-version": "2023-06-01" }, body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || "claude-3-5-haiku-latest", max_tokens: request.maxTokens ?? 2200, system: request.messages.find(message => message.role === "system")?.content, messages: request.messages.filter(message => message.role !== "system").map(message => ({ role: message.role, content: message.content })) }) });
  if (!response.ok) throw new Error(`Anthropic provider failed (${response.status})`);
  const json = await response.json() as { content?: Array<{ text?: string }> };
  return json.content?.map(part => part.text ?? "").join("") ?? "";
}

function parseJson<T>(raw: string): T {
  const normalized = raw.replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
  const start = normalized.indexOf("{");
  const end = normalized.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("AI provider returned no JSON object");
  return JSON.parse(normalized.slice(start, end + 1)) as T;
}

function contentToText(content: unknown): string { return typeof content === "string" ? content : Array.isArray(content) ? content.map(part => typeof part === "object" && part && "text" in part ? String((part as { text?: unknown }).text ?? "") : "").join("") : ""; }

export async function generateStructured<T>(request: StructuredRequest): Promise<{ value: T; provider: ProviderName }> {
  const provider = configuredProvider();
  if (!provider) throw new Error("AI provider is not configured");
  const raw = provider === "managed"
    ? contentToText((await invokeLLM({ model: process.env.NOTES_MODEL || undefined, messages: request.messages, maxTokens: request.maxTokens ?? 2200, responseFormat: { type: "json_schema", json_schema: { name: request.schemaName, strict: true, schema: request.schema } } })).choices?.[0]?.message?.content)
    : await invokeExternal(provider, request);
  if (!raw) throw new Error("AI provider returned an empty response");
  return { value: parseJson<T>(raw), provider };
}
