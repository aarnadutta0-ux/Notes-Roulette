export type DetailLevel = "concise" | "balanced" | "detailed";
export type VisualIntensity = "minimal" | "balanced" | "visual-heavy";
export type DiagramPreference = "automatic" | "more" | "fewer";

export type BookPreferences = {
  detailLevel: DetailLevel;
  visualIntensity: VisualIntensity;
  diagramPreference: DiagramPreference;
  includeSources: boolean;
};

export type SourceRef = { startPage: number; endPage: number; label?: string };

export type NoteSection = {
  id: string;
  title: string;
  summary: string;
  bullets: string[];
  keyTerms: string[];
  sourceRefs: SourceRef[];
  chapterTitle: string;
};

export type NoteVisual = {
  id: string;
  title: string;
  strategy: "generated" | "extracted" | "redrawn";
  kind: "timeline" | "flow" | "concept-map" | "comparison" | "formula" | "cycle";
  description: string;
  sourceRefs: SourceRef[];
  /** Pre-rendered SVG for the browser preview. */
  svg?: string;
  /** Chapter this visual belongs to, so the PDF can place it next to the right notes. */
  chapterTitle?: string;
  /** Central concept label (concept maps) or heading (flows). */
  centre?: string;
  /** Satellite concepts / ordered steps, derived from the chapter's key terms. */
  nodes?: string[];
};

export type QualityFinding = {
  severity: "low" | "medium" | "high";
  category: string;
  message: string;
  sourceRefs: SourceRef[];
  resolved: boolean;
};

export type GeneratedNotes = {
  title: string;
  subject: string;
  overview: string;
  sections: NoteSection[];
  visuals: NoteVisual[];
  findings: QualityFinding[];
  sourceWarnings: string[];
  generationMode: "ai" | "extractive";
};