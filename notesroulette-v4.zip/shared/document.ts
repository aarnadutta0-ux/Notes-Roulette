export type SupportedSourceKind = "pdf" | "docx" | "epub" | "image";

export type SourceImage = {
  id: string;
  pageNumber: number;
  alt?: string;
  storageKey?: string;
  dataUrl?: string;
};

export type DocumentPage = {
  pageNumber: number;
  text: string;
  rawText?: string;
  confidence: number;
  ocrRequired?: boolean;
  sourceKind: SupportedSourceKind;
  blocks: Array<{ type: "heading" | "paragraph" | "table" | "image"; text: string }>;
  images: SourceImage[];
};

export type DocumentSection = { id: string; title: string; level: 1 | 2 | 3; startPage: number; endPage: number; text: string; parentId?: string };
export type DocumentChapter = { id: string; title: string; startPage: number; endPage: number; sections: DocumentSection[]; text: string };
export type ExtractedDocument = { title: string; sourceKind: SupportedSourceKind; pageCount: number; pages: DocumentPage[]; chapters: DocumentChapter[]; extractedAt: string; warnings: string[] };
export type DocumentChunk = { id: string; chapterId: string; chapterTitle: string; startPage: number; endPage: number; text: string; index: number };
