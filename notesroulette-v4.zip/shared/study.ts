import type { SourceRef } from "./notes";

export type StudyScope = "book" | "chapter";
export type ExamQuestionType = "important" | "short" | "long" | "definition" | "key-fact";
export type StudyDifficulty = "easy" | "medium" | "hard" | "mixed";
export type QuizQuestionType = "multiple-choice" | "true-false";
export type QuizMode = "multiple-choice" | "true-false" | "mixed";
export type FlashcardState = "new" | "know" | "review";

export type ExamQuestion = {
  id: string;
  type: ExamQuestionType;
  prompt: string;
  answer: string;
  explanation: string;
  keywords: string[];
  framework?: string[];
  sourceRefs: SourceRef[];
};

export type ExamMaterial = {
  title: string;
  subject: string;
  scope: StudyScope;
  chapterTitle?: string;
  generationMode: "ai" | "extractive";
  questions: ExamQuestion[];
};

export type QuizQuestion = {
  id: string;
  type: QuizQuestionType;
  difficulty: Exclude<StudyDifficulty, "mixed">;
  prompt: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  topic: string;
  sourceRefs: SourceRef[];
};

export type QuizMaterial = {
  title: string;
  subject: string;
  scope: StudyScope;
  chapterTitle?: string;
  questionCount: number;
  difficulty: StudyDifficulty;
  mode: QuizMode;
  generationMode: "ai" | "extractive";
  questions: QuizQuestion[];
};

export type QuizAnswer = { questionId: string; selectedIndex: number | null };
export type QuizAttempt = {
  id?: number;
  answers: QuizAnswer[];
  score: number;
  total: number;
  percentage: number;
  weakTopics: string[];
};

export type Flashcard = {
  id: string;
  front: string;
  back: string;
  sourceRefs: SourceRef[];
  state: FlashcardState;
};

export type FlashcardMaterial = {
  title: string;
  subject: string;
  scope: StudyScope;
  chapterTitle?: string;
  generationMode: "ai" | "extractive";
  cards: Flashcard[];
};

export type StudyChapter = { title: string; startPage: number; endPage: number };
