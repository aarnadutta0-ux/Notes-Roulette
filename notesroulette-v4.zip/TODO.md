# Notes Roulette MVP — Delivery Outcomes

## Real document intake and private ownership

- Support PDF, EPUB, DOCX, JPG, JPEG and PNG uploads through a real backend endpoint/procedure.
- Validate actual file signatures/magic bytes, trusted MIME/extension consistency, non-empty content, configured size limits, corrupted containers, and actual PDF page count; reject documents over 500 pages with an understandable error.
- Store originals privately under a user-scoped key; persist only metadata/storage keys server-side; enforce authenticated ownership on every book, job, source, notes, PDF and preference operation.
- Prevent duplicate active submissions for the same owner/book content and clean up broken/temporary state after failed processing or deletion.

## Extraction, OCR, cleaning, structure and chunking

- Extract page-associated text, page boundaries, source locations and useful images/figures from PDF; paragraphs/headings/tables/images from DOCX; chapters/sections/text/images from EPUB; and route image documents through OCR/document analysis when available.
- Preserve page association and low-confidence/uncertain OCR markers, avoid invented text, remove contextual noise such as blank/copyright/ad/navigation/repeated header/footer material, repair broken hyphenation, preserve academically important repeated definitions/warnings, and detect title/chapter/section/topic structure without assuming textbook formatting.
- Produce bounded deterministic chunks with source page ranges and resumable chapter groupings.

## Source-grounded AI analysis and quality control

- Provide a common server-side provider interface for OpenAI, Google Gemini, Anthropic Claude and the configured managed LLM; never expose provider credentials in the browser.
- Treat uploaded content as untrusted source material that must never override system instructions; use structured, schema-validated outputs, retries/backoff, timeouts, rate-limit handling, bounded concurrency, provider fallback where configured, and recoverable job checkpoints.
- Process hierarchically from chapter/section detection through chunk analysis, chapter synthesis, whole-document synthesis, final notes, useful diagrams, and a separate QC pass; retain source page references and revise unsupported/duplicate/missing/contradictory output where practical.

## Persisted job lifecycle and PDF artifact

- Persist real processing states and stage/progress/chapter metadata for uploading, reading, cleaning, chapter detection, chapter analysis, notes, diagrams, quality checking, PDF building, complete and failed.
- Provide bounded retry, stale-job recovery, heartbeat/attempt metadata, safe user-facing errors, idempotency and no fake browser progress.
- Generate a real polished academic PDF from validated generated content, store it privately, expose ownership-checked preview/download access, and provide a browser notes preview.

## Complete frontend experience

- Build a colourful editorial landing page explaining “Upload your book. Let AI turn it into beautiful study notes.” with upload/sign-in CTA, supported formats, 500-page limit, subject versatility, process steps, diagram capability and PDF preview.
- Build authenticated dashboard, library, upload/customization, real processing, notes/PDF preview and settings screens with responsive navigation, loading/empty/error states, accessible interactions, source chips and controls for concise/balanced/detailed detail, minimal/balanced/visual-heavy visuals, automatic/more/fewer diagrams and source references.
- Show only the signed-in user’s books/jobs/notes, with title/date/subject/page count/status/open/download/delete actions; do not ship hardcoded books, dummy statuses, fake AI responses, fake PDFs or monetization UI.

## Authentication, security and deployment hygiene

- Preserve the real managed OAuth session contract for Preview, protected routes, logout, cross-site HTTPS cookie behavior and server-side authorization; keep Google sign-in behind a real server-side provider adapter and report it as blocked unless Google credentials/configuration are present rather than faking a Google login.
- Keep secrets server-side, preserve health/platform/storage routes, use safe errors and logs, and add route metadata plus deployment configuration only after the application builds and runs.

## Verification evidence

- Run type-check, frontend/backend build, existing tests and new unit/integration tests for validation, extraction/cleaning/chunking, structured AI parsing/retry, job transitions/ownership and PDF generation.
- Start the dev server and verify health, route manifest, landing page, protected route behavior, API errors and production start; exercise valid and invalid upload paths and a real small-document flow when managed storage/LLM credentials are available.
- Report Google OAuth, external provider, OCR and browser-rendering limitations only when actually blocked by missing credentials/binaries; never claim unexecuted tests as passing.
